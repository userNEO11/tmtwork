import React, { useState, useEffect } from 'react';
import { ScrollProgressBar } from './components/ScrollProgressBar';
import { Navbar } from './components/Navbar';
import { SitePreloader } from './components/SitePreloader';
import { Footer } from './components/Footer';
import { EnquiryModal } from './components/EnquiryModal';
import { DealerLocatorModal } from './components/DealerLocatorModal';
import { ArticleModal } from './components/ArticleModal';
import { CallNowFloatingButton } from './components/CallNowFloatingButton';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { ProductGrade, KNOWLEDGE_ARTICLES } from './data/tmtData';
import { LanguageProvider } from './context/LanguageContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';

// Dedicated Page Components
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProcessPage } from './pages/ProcessPage';
import { QualityPage } from './pages/QualityPage';
import { DealersPage } from './pages/DealersPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { AboutPage } from './pages/AboutPage';
import { TechnicalPage } from './pages/TechnicalPage';
import { ContactPage } from './pages/ContactPage';
import { ChairmanPage } from './pages/ChairmanPage';
import { CalculatorPage } from './pages/CalculatorPage';
import { updatePageSEO } from './utils/seo';

function MainApp() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [isLoaded, setIsLoaded] = useState(false);

  // Modals state
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const [isDealerOpen, setIsDealerOpen] = useState(false);
  const [enquiryInitialGrade, setEnquiryInitialGrade] = useState<string>('Fe 550D');
  const [selectedArticle, setSelectedArticle] = useState<typeof KNOWLEDGE_ARTICLES[0] | null>(null);

  // Dynamically update document title & SEO meta tags whenever current page changes
  useEffect(() => {
    updatePageSEO(currentPage);
  }, [currentPage]);

  // Listen to hash changes for direct deep-linking
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').trim().toLowerCase();
      if (['home', 'products', 'process', 'quality', 'dealers', 'projects', 'technical', 'about', 'contact', 'chairman', 'calculator', 'calc'].includes(hash)) {
        if (hash === 'calc') {
          setCurrentPage('calculator');
        } else {
          setCurrentPage(hash);
        }
      }
    };

    // Check initial hash on mount
    handleHashChange();

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (pageId: string) => {
    setCurrentPage(pageId);
    window.location.hash = pageId;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenEnquiryWithGrade = (grade?: string) => {
    if (grade) setEnquiryInitialGrade(grade);
    setIsEnquiryOpen(true);
  };

  const handleOpenArticleById = (articleId: string) => {
    const article = KNOWLEDGE_ARTICLES.find((a) => a.id === articleId) || KNOWLEDGE_ARTICLES[0];
    setSelectedArticle(article);
  };

  const { isDark } = useTheme();

  return (
    <div className={`min-h-screen ${isDark ? 'bg-[#0D0F12] text-zinc-100' : 'bg-white text-zinc-900'} font-sans selection:bg-[#FFD700] selection:text-black relative overflow-x-hidden transition-colors duration-300`}>
      {/* High Performance Preloader */}
      {!isLoaded && <SitePreloader onComplete={() => setIsLoaded(true)} />}

      {/* Viewport Scroll Progress Indicator */}
      <ScrollProgressBar />

      {/* Top Navbar with Multi-Page Navigation & Language Switcher */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onOpenEnquiry={() => handleOpenEnquiryWithGrade('Fe 550D')}
        onOpenDealer={() => handleNavigate('dealers')}
        onSelectProduct={(grade) => {
          setEnquiryInitialGrade(grade);
          handleNavigate('products');
        }}
        onOpenArticle={handleOpenArticleById}
      />

      {/* Main Multi-Page Container */}
      <main className="flex flex-col w-full pt-16 sm:pt-20 md:pt-24">
        {currentPage === 'home' && (
          <HomePage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
            onNavigate={handleNavigate}
            onSelectProduct={(product) => {
              setEnquiryInitialGrade(product.grade);
              handleNavigate('products');
            }}
            onOpenArticle={handleOpenArticleById}
          />
        )}

        {currentPage === 'products' && (
          <ProductsPage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'calculator' && (
          <CalculatorPage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'chairman' && (
          <ChairmanPage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'process' && (
          <ProcessPage
            onOpenEnquiry={() => handleOpenEnquiryWithGrade('Factory Mill Tour / Process')}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'quality' && (
          <QualityPage
            onOpenEnquiry={() => handleOpenEnquiryWithGrade('MTC Test Certificate Request')}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'dealers' && (
          <DealersPage onOpenEnquiry={handleOpenEnquiryWithGrade} />
        )}

        {currentPage === 'projects' && (
          <ProjectsPage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
          />
        )}

        {currentPage === 'technical' && (
          <TechnicalPage
            onOpenEnquiry={handleOpenEnquiryWithGrade}
            onOpenDealer={() => handleNavigate('dealers')}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage
            onOpenEnquiry={() => handleOpenEnquiryWithGrade('About Balwant / Corporate')}
            onOpenDealer={() => handleNavigate('dealers')}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'contact' && <ContactPage />}
      </main>

      {/* Global Footer with Page Links */}
      <Footer
        onNavigate={handleNavigate}
        onOpenEnquiry={() => handleOpenEnquiryWithGrade('Fe 550D')}
        onOpenDealer={() => handleNavigate('dealers')}
      />

      {/* Shared Modals */}
      <EnquiryModal
        isOpen={isEnquiryOpen}
        onClose={() => setIsEnquiryOpen(false)}
        initialGrade={enquiryInitialGrade}
      />

      <DealerLocatorModal
        isOpen={isDealerOpen}
        onClose={() => setIsDealerOpen(false)}
        onSelectDealer={(dealerName) => {
          setIsEnquiryOpen(true);
          setEnquiryInitialGrade(`Dealer Order: ${dealerName}`);
        }}
      />

      <ArticleModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
        onOpenEnquiry={() => handleOpenEnquiryWithGrade('Technical Article Inquiry')}
      />

      {/* Floating Call Now Quick Dial Toggle Button */}
      <CallNowFloatingButton />

      {/* Floating WhatsApp Sales Inquiry Button */}
      <WhatsAppFloatingButton />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <MainApp />
      </LanguageProvider>
    </ThemeProvider>
  );
}
