import balwantHomeBuilderImg from '../assets/images/balwant_indian_home_builder_1786953228879.jpg';
import balwantInfraImg from '../assets/images/balwant_infra_slider_1787645636350.jpg';
import balwantRebarBundleImg from '../assets/images/balwant_bundles_slider_1787645616843.jpg';
import balwantEngineersImg from '../assets/images/balwant_site_indian_engineers_1786953214603.jpg';
import balwantRibbedDetailImg from '../assets/images/balwant_embossed_bars_1787551863034.jpg';
import millImg from '../assets/images/balwant_mill_slider_1787645597876.jpg';
import balwantFe550dImg from '../assets/images/balwant_fe550d_slider_1787645576016.jpg';
import bridgeImg from '../assets/images/balwant_infra_site_pure_1787135693938.jpg';

export interface ProductGrade {
  id: string;
  grade: string;
  name: string;
  subheading: string;
  tagline: string;
  tag: string;
  yieldStrength: string;
  tensileStrength: string;
  elongation: string;
  description: string;
  keyFeatures: string[];
  recommendedFor: string[];
  isPrimary?: boolean;
}

export interface BarDiameter {
  diameterMm: number;
  weightPerMeterKg: number;
  tolerance: string;
  piecesPerBundle: number;
  metersPerBundle: number;
  primaryUse: string;
}

export const BALWANT_PRODUCTS: ProductGrade[] = [
  {
    id: '550d',
    grade: 'Fe 550D',
    name: 'Balwant TMT 550D',
    subheading: 'High Ductility Structural Reinforcement Steel',
    tagline: 'Engineered for high-stress seismic resistance and heavy structural loads.',
    tag: 'Flagship Grade',
    yieldStrength: 'Min 550 N/mm² (Typical 580 N/mm²)',
    tensileStrength: 'Min 600 N/mm² (Typical 645 N/mm²)',
    elongation: 'Min 16.0% (Uniform Elongation > 6%)',
    description:
      'Balwant 550D is engineered using specialized German Quenching & Self-Tempering (QST) technology. The "D" signifies superior ductility, delivering the perfect balance of massive yield strength and energy absorption capacity during seismic activity.',
    keyFeatures: [
      'Superior bendability & re-bendability without micro-fractures',
      'High resistance against cyclical earthquake loads (Zone IV & V compliant)',
      'Low Carbon Equivalent (C.E. < 0.42%) for flawless on-site weldability',
      'Consistent AR (Area of Ribs) ratio exceeding IS 1786:2008 standards',
    ],
    recommendedFor: [
      'Multi-story residential towers & high-rises',
      'Bridges, flyovers & metro elevated corridors',
      'Critical commercial infrastructure & hospitals',
      'Individual residential dream homes and villas',
    ],
    isPrimary: true,
  },
  {
    id: '600',
    grade: 'Fe 600',
    name: 'Balwant TMT 600',
    subheading: 'Ultra-High Tensile Heavy Infrastructure Grade',
    tagline: 'Maximum load-bearing density with up to 18% steel weight optimization.',
    tag: 'High Tensile Heavy Duty',
    yieldStrength: 'Min 600 N/mm² (Typical 630 N/mm²)',
    tensileStrength: 'Min 660 N/mm² (Typical 710 N/mm²)',
    elongation: 'Min 12.0%',
    description:
      'Engineered for mega-load structures requiring extreme yield capacity. Balwant Fe 600 permits structural engineers to reduce steel congestion in heavily reinforced shear walls, deep foundation footings, and long-span spans.',
    keyFeatures: [
      'Up to 15-18% steel consumption reduction compared to Fe 415/Fe 500',
      'Reduces column rebar crowding for seamless concrete pouring',
      'Exceptional thermal resistance up to 600°C fire threshold',
      'Advanced metallurgy with micro-alloyed vanadium and boron chemistry',
    ],
    recommendedFor: [
      'Expressways, heavy freight rail corridors & airport runways',
      'Thermal & hydro-electric power plant structures',
      'Deep basement rafts, retaining walls & industrial silos',
      'Industrial crane-gantry foundation columns',
    ],
  },
  {
    id: 'crs',
    grade: 'Balwant CRS',
    name: 'Balwant Corrosion Resistant Steel',
    subheading: 'Specialized Marine & High-Moisture Foundation Steel',
    tagline: 'Copper, Chromium & Phosphorus enriched matrix against moisture and saline attack.',
    tag: 'Corrosion Shield',
    yieldStrength: 'Min 500 / 550 N/mm²',
    tensileStrength: 'Min 565 / 600 N/mm²',
    elongation: 'Min 16.0%',
    description:
      'Corrosion is the single largest cause of premature concrete spalling and reinforcement failure. Balwant CRS contains engineered micro-alloys that produce an invisible, self-healing protective passivation oxide layer.',
    keyFeatures: [
      'Up to 2.5x longer lifespan in saline, coastal, and aggressive groundwater',
      'Continuous passivation film arrests chloride and sulphate penetration',
      'No secondary epoxy coating peel-off risks during handling and bending',
      'Maintains full core ductility and structural bond strength',
    ],
    recommendedFor: [
      'Coastal residential & port infrastructure',
      'Water treatment plants, dams & sewage canals',
      'Underground basement retaining structures in saline water tables',
      'Chemical & fertilizer storage industrial floors',
    ],
  },
];

export const BAR_DIAMETERS: BarDiameter[] = [
  { diameterMm: 8, weightPerMeterKg: 0.395, tolerance: '±7.0%', piecesPerBundle: 24, metersPerBundle: 288, primaryUse: 'Stirrups, Ties, Slab Mesh' },
  { diameterMm: 10, weightPerMeterKg: 0.617, tolerance: '±7.0%', piecesPerBundle: 16, metersPerBundle: 192, primaryUse: 'Slabs, Cantilever Overhangs, Light Beams' },
  { diameterMm: 12, weightPerMeterKg: 0.888, tolerance: '±5.0%', piecesPerBundle: 10, metersPerBundle: 120, primaryUse: 'Primary Beams, Residential Columns, Lintels' },
  { diameterMm: 16, weightPerMeterKg: 1.580, tolerance: '±5.0%', piecesPerBundle: 6, metersPerBundle: 72, primaryUse: 'Heavy Columns, Foundation Footings, Grade Beams' },
  { diameterMm: 20, weightPerMeterKg: 2.470, tolerance: '±3.0%', piecesPerBundle: 4, metersPerBundle: 48, primaryUse: 'High-Rise Columns, Bridge Girders, Heavy Rafts' },
  { diameterMm: 25, weightPerMeterKg: 3.850, tolerance: '±3.0%', piecesPerBundle: 2, metersPerBundle: 24, primaryUse: 'Shear Walls, Heavy Infrastructure Piles, Retaining Walls' },
  { diameterMm: 32, weightPerMeterKg: 6.310, tolerance: '±3.0%', piecesPerBundle: 1, metersPerBundle: 12, primaryUse: 'Mega Dam Spillways, Metro Piers, Heavy Foundation Piles' },
];

export const PROCESS_STEPS = [
  {
    step: '01',
    name: 'RAW MATERIAL SELECTION',
    highlight: 'Virgin Sponge Iron & Selected Billets',
    description: 'We utilize strictly controlled prime raw materials with restricted sulphur and phosphorus levels (< 0.035%) to eliminate cold shortness and brittleness.',
    stat: '< 0.035% S+P Levels',
  },
  {
    step: '02',
    name: 'CONTINUOUS ROLLING',
    highlight: 'Computerized High-Speed Stands',
    description: 'Billets are heated to 1150°C and processed through high-precision tungsten-carbide rolling stands to form uniform cross-sectional ribs and flawless dimensional tolerance.',
    stat: '1150°C Reheating Precision',
  },
  {
    step: '03',
    name: 'THERMEX QST QUENCHING',
    highlight: 'Advanced Quenching & Self-Tempering',
    description: 'The hot bar undergoes intense high-pressure water quenching. The outer surface converts to tempered Martensite, while the core remains ductile Ferrite-Pearlite.',
    stat: 'Dual Microstructure Matrix',
  },
  {
    step: '04',
    name: 'QUALITY & SPECTROMETRY',
    highlight: 'Universal Testing Machine & Chemical Assay',
    description: 'Every manufacturing heat batch is tested on 100-ton UTM for yield stress, tensile ratio (UTS/YS > 1.15), 180° cold bend, re-bend, and spectrometer element verification.',
    stat: '100% Heat Batch Tested',
  },
  {
    step: '05',
    name: 'FINISHED BALWANT TMT',
    highlight: 'Embossed Hallmark & Precision Bundles',
    description: 'Bars are automated-cut to 12-meter lengths, branded with the embossed Balwant TMT hallmark, tagged with QR traceability, and stored in moisture-protected bays.',
    stat: '12-Meter Standard Bar Length',
  },
];

export const WHY_BALWANT_PILLARS = [
  {
    num: '01',
    title: 'UNRIVALED STRENGTH',
    sub: 'Beyond Standard Load Thresholds',
    desc: 'Balwant TMT exceeds the mandatory IS 1786:2008 standards by over 15%. Its high yield strength ensures structures withstand extraordinary dead loads, dynamic wind stress, and live vibrations with zero plastic deformation.',
    metrics: [
      { label: 'Yield Strength', val: '580+ N/mm²' },
      { label: 'Tensile Ratio', val: '1.20x' },
    ],
  },
  {
    num: '02',
    title: 'SUPERIOR DUCTILITY',
    sub: 'Engineered for Earthquake Zones IV & V',
    desc: 'During severe seismic shaking, ordinary rebar snaps abruptly. Balwant 550D features a soft ferrite-pearlite inner core that bends and absorbs violent kinetic energy without catastrophic shear failure.',
    metrics: [
      { label: 'Elongation', val: '16.5%+' },
      { label: 'Re-bend Angle', val: '135° Safe' },
    ],
  },
  {
    num: '03',
    title: 'THERMAL RESISTANCE',
    sub: 'Safety up to 600°C Heat Exposure',
    desc: 'The tempered martensite outer rim retains structural load integrity even under prolonged intense fire emergencies, giving occupants critical evacuation time compared to ordinary cold twisted bars.',
    metrics: [
      { label: 'Fire Threshold', val: 'Up to 600°C' },
      { label: 'Thermal Retention', val: '88% Strength' },
    ],
  },
  {
    num: '04',
    title: 'TOTAL RELIABILITY',
    sub: 'Computerized Rib Geometry & Concrete Grip',
    desc: 'Our high-aspect transverse rib pattern provides superior mechanical interlock with concrete. This prevents concrete slippage and eliminates structural micro-cracking across decades of environmental wear.',
    metrics: [
      { label: 'Rib Area (AR)', val: '> 0.085' },
      { label: 'Bond Strength', val: '2.4x Standard' },
    ],
  },
];

export const APPLICATIONS = [
  {
    title: 'RESIDENTIAL HOMES',
    hindi: 'सपनों का आशियाना',
    desc: 'Every home foundation deserves generational permanence. Balwant TMT gives Indian homeowners complete peace of mind against earth tremors and dampness.',
    span: 'col-span-12 md:col-span-7',
    image: balwantHomeBuilderImg,
    tag: 'Indian Homes & Villas',
  },
  {
    title: 'COMMERCIAL TOWERS',
    hindi: 'गगनचुंबी इमारतें',
    desc: 'High-rise shear columns and transfer slabs engineered for massive vertical loads and wind shear forces in modern Indian metropolitan cities.',
    span: 'col-span-12 md:col-span-5',
    image: balwantEngineersImg,
    tag: 'High Rises & Malls',
  },
  {
    title: 'HEAVY INDUSTRIAL PLANTS',
    hindi: 'औद्योगिक संयंत्र',
    desc: 'Heavy machinery bases, gantry rail foundations, and furnace bays subjected to cyclical vibration and high temperatures.',
    span: 'col-span-12 md:col-span-5',
    image: millImg,
    tag: 'Industrial & Warehouses',
  },
  {
    title: 'NATIONAL INFRASTRUCTURE',
    hindi: 'राष्ट्र निर्माण',
    desc: 'Flyovers, metro viaducts, railway overpasses, expressways, and bridges engineered with Balwant TMT to serve the nation for a century.',
    span: 'col-span-12 md:col-span-7',
    image: balwantInfraImg,
    tag: 'Bridges, Metros & Expressways',
  },
];

export const PROJECTS = [
  {
    id: 'p1',
    name: 'ELEVATED EXPRESSWAY CORRIDOR',
    type: 'National Highway Infrastructure',
    location: 'Central Corridor, India',
    steelUsed: '14,500 Metric Tonnes',
    grade: 'Balwant Fe 550D / Fe 600',
    image: balwantInfraImg,
    quote: 'Engineered for continuous heavy 60-tonne freight axle loading across a 42 km elevated Indian expressway viaduct.',
  },
  {
    id: 'p2',
    name: 'METRO RAIL ELEVATED PIER SECTION',
    type: 'Urban Transit Infrastructure',
    location: 'Indian Metropolitan Rail Network',
    steelUsed: '18,200 Metric Tonnes',
    grade: 'Balwant Fe 550D',
    image: balwantFe550dImg,
    quote: 'High seismic ductility Balwant 550D utilized in all deep pile caps, cantilever pier arms, and elevated tracks.',
  },
  {
    id: 'p3',
    name: 'RIVER KRISHNA MULTI-SPAN BRIDGE',
    type: 'Riverine Bridge & Pier Foundations',
    location: 'Eastern River Basin, India',
    steelUsed: '6,400 Metric Tonnes',
    grade: 'Balwant CRS (Corrosion Resistant)',
    image: bridgeImg,
    quote: 'Balwant CRS alloyed rebar ensures deep underwater pier cages resist high salinity and water erosion.',
  },
  {
    id: 'p4',
    name: 'PREMIUM RESIDENTIAL TOWERS & TOWNSHIPS',
    type: 'Residential High-Rise Complex',
    location: 'National Capital Region, India',
    steelUsed: '9,800 Metric Tonnes',
    grade: 'Balwant Fe 550D',
    image: balwantHomeBuilderImg,
    quote: 'Selected for flawless ductile bendability and total structural safety for over 2,400 Indian families.',
  },
];

export const KNOWLEDGE_ARTICLES = [
  {
    id: 'art-1',
    title: 'Fe 500 vs Fe 550D: Why "D" Saves Lives in Earthquakes',
    readTime: '4 min read',
    category: 'Structural Engineering',
    summary: 'Discover why standard rebar is prone to brittle shear fractures, and how the micro-alloyed Ferrite-Pearlite core of Balwant 550D acts as an energy shock absorber during tectonic movement.',
    image: balwantRebarBundleImg,
  },
  {
    id: 'art-2',
    title: 'The Science of Rib Geometry: How AR Dictates Concrete Grip',
    readTime: '3 min read',
    category: 'Metallurgy',
    summary: 'Concrete alone has high compressive strength but zero tensile elasticity. Learn how Balwant\'s automated CNC cut rib grooves form an unbreakable mechanical bond with cement paste.',
    image: balwantEngineersImg,
  },
  {
    id: 'art-3',
    title: 'Site Checklist: 5 Quick Tests to Verify Genuine Balwant TMT',
    readTime: '5 min read',
    category: 'Indian Builder Guide',
    summary: 'From checking the embossed BIS hallmark and batch test certification to performing the simple 180° cold bend test on your site before concrete pouring.',
    image: balwantRibbedDetailImg,
  },
];
