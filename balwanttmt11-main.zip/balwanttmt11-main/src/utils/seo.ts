// Page SEO Metadata Definitions and Dynamic Head Updater

export interface PageSEO {
  title: string;
  description: string;
  keywords?: string;
  path: string;
}

export const PAGE_SEO_DATA: Record<string, PageSEO> = {
  home: {
    title: 'Balwant Super TMT | सरिया नहीं, फौलाद है ये - Premium Fe 550D Steel Rebar',
    description: "Official website of Balwant Super TMT steel rebar. German Thermex QST technology, high ductile Fe 550D, corrosion resistant CRS steel for residential, commercial & infrastructure projects. An associate of Singh Aluminium Company Limited.",
    keywords: 'Balwant Super TMT, Fe 550D TMT Bar, Fe 600 steel bar, TMT saria price, best TMT bar in India, earthquake resistant steel, Thermex QST, BIS certified TMT, Singh Aluminium Company Limited, सरिया नहीं फौलाद है ये',
    path: '#home',
  },
  products: {
    title: 'TMT Products & Grades | Balwant Super TMT Fe 550D, Fe 600 & CRS Saria',
    description: 'Explore the complete Balwant Super TMT rebar lineup: Fe 500D, Fe 550D High-Ductility, Fe 600 High-Strength, and CRS Corrosion-Resistant Rebars in 8mm to 32mm diameters with full technical specifications.',
    keywords: 'Balwant TMT products, Fe 550D specifications, Fe 600 saria, CRS corrosion resistant steel, 8mm 10mm 12mm 16mm 20mm 25mm 32mm TMT bar',
    path: '#products',
  },
  calculator: {
    title: 'Steel Quantity & Cost Calculator | Balwant Super TMT Saria Estimation',
    description: 'Calculate exact steel rebar requirements for home construction, slabs, beams, columns, and foundations. Estimate TMT bar weight in kg, bundles, and total project cost instantly.',
    keywords: 'steel calculator for house construction, TMT saria weight calculator, calculate rebar for slab beam column, Balwant TMT cost estimator',
    path: '#calculator',
  },
  chairman: {
    title: "Chairman's Desk | P.N Singh - Balwant Steel & Power (Singh Aluminium Associate)",
    description: "Read the visionary message from Chairman P.N Singh on nation-building, unmatched metallurgy standards, industrial safety, and 30+ years of manufacturing legacy at Balwant Steel and Power.",
    keywords: 'P.N Singh Chairman Balwant, Balwant Steel and Power leadership, Singh Aluminium Company Limited associate, Chairman desk message',
    path: '#chairman',
  },
  process: {
    title: 'Manufacturing Process & German QST Mill | Balwant Super TMT Rebar',
    description: 'Discover how Balwant Super TMT steel is crafted: computerized electric arc furnace, primary refining, ladle refining furnace, continuous billet casting, and automated German Thermex QST quenching.',
    keywords: 'TMT manufacturing process, German Thermex QST quenching, continuous billet casting, steel rolling mill, primary steel making',
    path: '#process',
  },
  quality: {
    title: 'Quality Assurance & BIS Certification (IS 1786) | Balwant Super TMT',
    description: 'Learn about Balwant Super TMT rigorous quality control: universal tensile testing, 180-degree bend & rebend tests, spectrometer chemical analysis, and Mill Test Certificates (MTC).',
    keywords: 'IS 1786 BIS certification, MTC test certificate, TMT tensile strength testing, elongation percentage, chemical composition steel',
    path: '#quality',
  },
  dealers: {
    title: 'Authorized Dealer Locator & Network | Buy Genuine Balwant Super TMT',
    description: 'Find verified Balwant Super TMT dealers, stockists, and distributors across India or apply for an authorized dealership partnership with direct mill supply and marketing support.',
    keywords: 'Balwant TMT dealer locator, TMT distributor near me, steel dealership business, buy original Balwant saria',
    path: '#dealers',
  },
  projects: {
    title: 'Landmark Infrastructure & Construction Projects | Balwant Super TMT',
    description: 'Explore major infrastructure projects, highways, metro flyovers, bridges, commercial complexes, and residential townships constructed with Balwant Super TMT steel across India.',
    keywords: 'Balwant TMT infrastructure projects, metro flyover steel, commercial towers construction, highway bridges TMT rebar',
    path: '#projects',
  },
  technical: {
    title: 'Technical Specifications & Engineering Library | Balwant Super TMT Rebars',
    description: 'Comprehensive engineering specifications, sectional weights, yield strength tolerances, elongation curves, chemical composition limits, and construction best practices for architects and civil engineers.',
    keywords: 'TMT engineering handbook, steel weight chart per meter, yield stress Fe 550D, civil engineering rebar specifications',
    path: '#technical',
  },
  about: {
    title: 'About Us - Heritage, Mission & Infrastructure | Balwant Steel & Power',
    description: 'Discover the history and heritage of Balwant Steel & Power, an associate of Singh Aluminium Company Limited. 30+ years of steel manufacturing excellence, state-of-the-art infrastructure, and pan-India reach.',
    keywords: 'About Balwant Super TMT, Balwant Steel and Power company profile, Singh Aluminium Company Limited heritage, Indian steel manufacturer',
    path: '#about',
  },
  contact: {
    title: 'Contact Us - Corporate Office, Zonal Offices & Sales Inquiries | Balwant Super TMT',
    description: 'Get in touch with Balwant Steel & Power. Corporate Office: Greater Noida Sector 1. Zonal Offices: Bhilai (C.G) & Lucknow (U.P). Call +91 8817303963 / +91 8839838970 or email contact@balwanttmt.com.',
    keywords: 'Contact Balwant TMT, Balwant Steel and Power Greater Noida, Bhilai Zonal Office, Lucknow Zonal Office, TMT sales phone number, bulk steel price inquiry',
    path: '#contact',
  },
};

/**
 * Dynamically updates document title, meta description, keywords, canonical link,
 * and Open Graph / Twitter cards for enhanced search engine indexing.
 */
export function updatePageSEO(pageId: string) {
  const seo = PAGE_SEO_DATA[pageId] || PAGE_SEO_DATA.home;

  // 1. Update Document Title
  document.title = seo.title;

  // Helper to safely set or create meta tag
  const setMetaTag = (attrName: string, attrVal: string, content: string) => {
    let element = document.querySelector(`meta[${attrName}="${attrVal}"]`) as HTMLMetaElement | null;
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute(attrName, attrVal);
      document.head.appendChild(element);
    }
    element.setAttribute('content', content);
  };

  // 2. Primary Meta Tags
  setMetaTag('name', 'title', seo.title);
  setMetaTag('name', 'description', seo.description);
  if (seo.keywords) {
    setMetaTag('name', 'keywords', seo.keywords);
  }

  // 3. Open Graph / Facebook Meta Tags
  setMetaTag('property', 'og:title', seo.title);
  setMetaTag('property', 'og:description', seo.description);
  setMetaTag('property', 'og:type', 'website');
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://balwanttmt.com';
  const fullUrl = `${currentOrigin}/${seo.path}`;
  setMetaTag('property', 'og:url', fullUrl);
  setMetaTag('property', 'og:site_name', 'Balwant Super TMT');

  // 4. Twitter Cards
  setMetaTag('name', 'twitter:card', 'summary_large_image');
  setMetaTag('name', 'twitter:title', seo.title);
  setMetaTag('name', 'twitter:description', seo.description);

  // 5. Canonical Link
  let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!canonical) {
    canonical = document.createElement('link');
    canonical.setAttribute('rel', 'canonical');
    document.head.appendChild(canonical);
  }
  canonical.setAttribute('href', fullUrl);
}
