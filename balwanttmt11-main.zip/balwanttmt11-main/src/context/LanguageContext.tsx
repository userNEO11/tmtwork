import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type Language = 'en' | 'hi';

export interface Translations {
  // Navigation
  nav: {
    home: string;
    about: string;
    whyBalwant: string;
    products: string;
    process: string;
    quality: string;
    projects: string;
    technical: string;
    knowledge: string;
    calculator: string;
    chairman: string;
    enquireNow: string;
    dealerLocator: string;
    tollFree: string;
    bisCertified: string;
    qstTech: string;
  };
  // Hero
  hero: {
    precisionEngineering: string;
    headlinePart1: string;
    headlinePart2: string;
    headlinePart3: string;
    tagline: string;
    subtext: string;
    exploreBtn: string;
    talkToUsBtn: string;
    gradeBadge: string;
    gradeSub: string;
    qualityBadge: string;
    certifiedBadge: string;
    structuralIntegrity: string;
  };
  // Brand Statement
  statement: {
    quote: string;
    author: string;
    authorTitle: string;
    certifiedTag: string;
  };
  // About
  about: {
    badge: string;
    title1: string;
    title2: string;
    desc1: string;
    desc2: string;
    metric1Val: string;
    metric1Label: string;
    metric2Val: string;
    metric2Label: string;
    metric3Val: string;
    metric3Label: string;
    metric4Val: string;
    metric4Label: string;
  };
  // Why Balwant
  whyBalwant: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
  };
  // Products
  products: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
    requestQuote: string;
    viewSpecs: string;
  };
  // Process
  process: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
  };
  // Quality
  quality: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
  };
  // Technical / Estimator
  technical: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
    estimatorTitle: string;
    estimatorSub: string;
    builtUpArea: string;
    floors: string;
    structureType: string;
    resOption: string;
    commOption: string;
    heavyOption: string;
    totalSteelNeeded: string;
    totalArea: string;
    breakdownTitle: string;
    vaultTitle: string;
    vaultDesc: string;
  };
  // Human Connection
  human: {
    badge: string;
    title1: string;
    title2: string;
    title3: string;
    quote: string;
    desc: string;
    cardTag: string;
    cardQuote: string;
    stat1Val: string;
    stat1Label: string;
    stat2Val: string;
    stat2Label: string;
  };
  // Dealer CTA
  dealerCta: {
    badge: string;
    title1: string;
    title2: string;
    desc: string;
    findDealerBtn: string;
    becomePartnerBtn: string;
    enquireBtn: string;
  };
  // Final CTA
  finalCta: {
    title1: string;
    title2: string;
    tagline: string;
    subtitle: string;
    enquireBtn: string;
  };
  // Footer
  footer: {
    desc: string;
    productsTitle: string;
    engineeringTitle: string;
    connectTitle: string;
    address: string;
    tollFree: string;
    locateDealer: string;
    getQuote: string;
  };
  // Modals & Common
  common: {
    close: string;
    submit: string;
    fullName: string;
    phone: string;
    city: string;
    projectType: string;
    tmtGrade: string;
    quantity: string;
    notes: string;
    searchDistrict: string;
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      home: 'HOME',
      about: 'ABOUT',
      whyBalwant: 'WHY BALWANT',
      products: 'PRODUCTS',
      process: 'PROCESS',
      quality: 'QUALITY',
      projects: 'PROJECTS',
      technical: 'TECHNICAL',
      knowledge: 'KNOWLEDGE',
      calculator: 'ESTIMATOR',
      chairman: "CHAIRMAN'S DESK",
      enquireNow: 'ENQUIRE NOW',
      dealerLocator: 'Dealer Locator',
      tollFree: 'TOLL FREE: 1800-120-TMT',
      bisCertified: 'BIS IS:1786:2008 CERTIFIED',
      qstTech: 'German Thermex QST Technology',
    },
    hero: {
      precisionEngineering: 'Precision Metallurgy & High Tensile Steel',
      headlinePart1: 'STRENGTH',
      headlinePart2: 'THAT BUILDS',
      headlinePart3: 'TOMORROW.',
      tagline: '“सरिया नही, फौलाद है ये”',
      subtext: 'Balwant TMT Fe 550D rebar forged with German Thermex QST technology — delivering earthquake-proof ductility, higher bond strength, and generational structural permanence.',
      exploreBtn: 'EXPLORE TMT PRODUCTS',
      talkToUsBtn: 'TALK TO AN ENGINEER',
      gradeBadge: 'Fe 550D',
      gradeSub: 'HIGH DUCTILITY CRS',
      qualityBadge: 'Fe 600',
      certifiedBadge: 'ISI LICENSED',
      structuralIntegrity: 'Structural Integrity',
    },
    statement: {
      quote: '“True strength isn’t seen from the outside. It stands silently inside every column, holding families safe for generations.”',
      author: 'BALWANT TMT',
      authorTitle: 'National Quality Benchmark in High-Tensile Steel',
      certifiedTag: 'BIS IS: 1786 COMPLIANT',
    },
    about: {
      badge: 'INDIAN STRUCTURAL EXCELLENCE',
      title1: 'ENGINEERED FOR',
      title2: 'GENERATIONS.',
      desc1: 'Balwant TMT is manufactured in state-of-the-art automated rolling mills utilizing primary raw steel billets and computerized German Thermex Quenching & Self-Tempering (QST) technology.',
      desc2: 'Every rebar delivers exact dimensional tolerance, consistent tensile yield, and unmatched bond strength with concrete to safeguard homes, expressways, and national landmarks.',
      metric1Val: '1,50,000+',
      metric1Label: 'Structures Fortified Pan-India',
      metric2Val: 'Fe 550D',
      metric2Label: 'Flagship Grade with 16%+ Elongation',
      metric3Val: '500+',
      metric3Label: 'Certified District Distribution Centers',
      metric4Val: '100%',
      metric4Label: 'Primary Billet Refining Standard',
    },
    whyBalwant: {
      badge: 'THE FOUR PILLARS OF FOULAAD',
      title1: 'WHY BALWANT',
      title2: 'LEADS THE NATION.',
      subtitle: 'Engineered beyond basic IS:1786 mandates to provide the safety margin structural consultants demand.',
    },
    products: {
      badge: 'PRECISION STRUCTURAL PORTFOLIO',
      title1: 'OUR TMT STEEL',
      title2: 'RANGE.',
      subtitle: 'From individual dream residences to mega infrastructure corridors, Balwant delivers tailored metallurgical grades.',
      requestQuote: 'REQUEST PRICE QUOTE',
      viewSpecs: 'VIEW SPECIFICATIONS',
    },
    process: {
      badge: 'GERMAN THERMEX QST TECHNOLOGY',
      title1: 'HOW WE FORGE',
      title2: 'PERFECTION.',
      subtitle: 'A fully automated 5-stage thermo-mechanical treatment process delivering a hardened tempered martensite perimeter with an ultra-ductile ferrite-pearlite core.',
    },
    quality: {
      badge: 'METALLURGICAL BENCHMARKS & NABL LABS',
      title1: 'PRECISION QUALITY',
      title2: 'WITHOUT COMPROMISE.',
      subtitle: 'Continuous online spectro-chemical testing and physical stress validation ensures zero impurities and zero defective batches.',
    },
    technical: {
      badge: 'ENGINEERING COMPLIANCE & ESTIMATION',
      title1: 'BUILT FOR',
      title2: 'ENGINEERS.',
      subtitle: 'Complete technical documentation, weight tolerance charts, and precision quantity estimators for structural consultants and contractors.',
      estimatorTitle: 'TMT STEEL ESTIMATOR',
      estimatorSub: 'Structural Quantity Forecaster',
      builtUpArea: 'Ground Built-up Area',
      floors: 'Total Floors (G + N)',
      structureType: 'Structure Classification',
      resOption: 'Residential Villa / Independent House',
      commOption: 'Commercial Complex / High-Rise',
      heavyOption: 'Heavy Industrial Shed / Factory Raft',
      totalSteelNeeded: 'TOTAL ESTIMATED STEEL REQUIRED',
      totalArea: 'Total Area',
      breakdownTitle: 'RECOMMENDED DIAMETER RATIO BREAKDOWN:',
      vaultTitle: 'OFFICIAL CERTIFICATION VAULT',
      vaultDesc: 'Download verified test certificates, ISI bureau licenses, chemical analysis sheets, and structural design catalogs.',
    },
    human: {
      badge: 'BEYOND THE STEEL',
      title1: 'EVERY BAR',
      title2: 'BUILDS MORE THAN',
      title3: 'A STRUCTURE.',
      quote: '“Behind every foundation is a dream. Behind every structure is a decision to build it strong.”',
      desc: 'Steel will forever remain hidden inside columns and concrete slabs. You will never see it again once your walls are painted. That is why the steel you choose on day one must be absolute, uncompromising, and permanent.',
      cardTag: 'FOR THE HOME YOU LOVE',
      cardQuote: 'A home isn’t just brick and mortar. It’s where children grow, families celebrate, and dreams take shape.',
      stat1Val: '100+ YEARS',
      stat1Label: 'Generational Structural Life',
      stat2Val: 'ZERO CRACKS',
      stat2Label: 'Superior Concrete Interlock',
    },
    dealerCta: {
      badge: 'DEALER & BUILDER NETWORK',
      title1: "LET'S BUILD",
      title2: 'SOMETHING STRONG.',
      desc: "Connect with your authorized district distributor or join India's fastest growing premium steel network as an authorized dealer.",
      findDealerBtn: 'FIND A DEALER',
      becomePartnerBtn: 'BECOME A PARTNER',
      enquireBtn: 'ENQUIRE NOW',
    },
    finalCta: {
      title1: 'BUILD STRONG.',
      title2: 'BUILD BALWANT.',
      tagline: '“सरिया नहीं, फौलाद है ये”',
      subtitle: 'Ready to fortify your residential project, commercial development, or national infrastructure?',
      enquireBtn: 'ENQUIRE NOW',
    },
    footer: {
      desc: "Balwant TMT is India's high-tensile structural reinforcement steel, forged through German Thermex QST quenching for zero-compromise foundations.",
      productsTitle: 'PRODUCTS',
      engineeringTitle: 'ENGINEERING',
      connectTitle: 'CONNECT WITH US',
      address: 'Corporate Central & Industrial Manufacturing Plant, India',
      tollFree: 'TOLL FREE',
      locateDealer: 'Locate Dealer',
      getQuote: 'Get Quote',
    },
    common: {
      close: 'CLOSE',
      submit: 'SUBMIT ENQUIRY',
      fullName: 'Your Full Name *',
      phone: 'Mobile Number *',
      city: 'City / Project Location *',
      projectType: 'Project Classification',
      tmtGrade: 'TMT Grade Required',
      quantity: 'Estimated Requirement',
      notes: 'Additional Notes / Bar Sizes',
      searchDistrict: 'Search by city, district or state...',
    },
  },
  hi: {
    nav: {
      home: 'होम',
      about: 'परिचय',
      whyBalwant: 'बलवंत ही क्यों',
      products: 'उत्पाद',
      process: 'प्रक्रिया',
      quality: 'गुणवत्ता',
      projects: 'परियोजनाएं',
      technical: 'तकनीकी',
      knowledge: 'ज्ञान केंद्र',
      calculator: 'कैलकुलेटर',
      chairman: 'चेयरमैन संदेश',
      enquireNow: 'पूछताछ करें',
      dealerLocator: 'डीलर खोजें',
      tollFree: 'टोल फ्री: 1800-120-TMT',
      bisCertified: 'BIS IS:1786:2008 प्रमाणित',
      qstTech: 'जर्मन थर्मैक्स QST तकनीक',
    },
    hero: {
      precisionEngineering: 'सटीक धातु विज्ञान और उच्च शक्ति सरिया',
      headlinePart1: 'ताकत',
      headlinePart2: 'जो गढ़े',
      headlinePart3: 'कल की नींव।',
      tagline: '“सरिया नही, फौलाद है ये”',
      subtext: 'बलवंत टीएमटी Fe 550D सरिया जर्मन थर्मैक्स QST तकनीक से निर्मित — भूकंप-रोधी लचीलापन, कंक्रीट के साथ अटूट पकड़ और पीढ़ियों तक चलने वाली मजबूती।',
      exploreBtn: 'उत्पाद देखें',
      talkToUsBtn: 'इंजीनियर से बात करें',
      gradeBadge: 'Fe 550D',
      gradeSub: 'उच्च लचीलापन CRS',
      qualityBadge: 'Fe 600',
      certifiedBadge: 'ISI प्रमाणित',
      structuralIntegrity: 'संरचनात्मक अखंडता',
    },
    statement: {
      quote: '“सच्ची ताकत बाहर से नहीं दिखती। यह हर खंभे के भीतर खामोशी से खड़ी रहती है और पीढ़ियों तक परिवारों को सुरक्षित रखती है।”',
      author: 'बलवंत टीएमटी',
      authorTitle: 'उच्च-क्षमता स्टील में राष्ट्रीय गुणवत्ता मानक',
      certifiedTag: 'BIS IS: 1786 अनुरूप',
    },
    about: {
      badge: 'भारतीय संरचनात्मक उत्कृष्टता',
      title1: 'पीढ़ियों की सुरक्षा के लिए',
      title2: 'निर्मित।',
      desc1: 'बलवंत टीएमटी अत्याधुनिक स्वचालित रोलिंग मिलों में प्राथमिक स्टील बिलेट्स और कम्प्यूटरीकृत जर्मन थर्मैक्स क्वेंचिंग और सेल्फ-टेम्परिंग (QST) तकनीक द्वारा निर्मित होता है।',
      desc2: 'प्रत्येक सरिया सटीक वजन, सुसंगत तन्य क्षमता और कंक्रीट के साथ अद्वितीय इंटरलॉक प्रदान करता है ताकि आपके घर, पुल और इमारतें हमेशा सुरक्षित रहें।',
      metric1Val: '1,50,000+',
      metric1Label: 'देश भर में मजबूत बनाई गई इमारतें',
      metric2Val: 'Fe 550D',
      metric2Label: '16%+ लचीलेपन वाला प्रमुख ग्रेड',
      metric3Val: '500+',
      metric3Label: 'प्रमाणित जिला वितरण केंद्र',
      metric4Val: '100%',
      metric4Label: 'शुद्ध प्राइमरी बिलेट मानक',
    },
    whyBalwant: {
      badge: 'फौलाद के चार मुख्य स्तंभ',
      title1: 'बलवंत टीएमटी',
      title2: 'ही क्यों चुनें?',
      subtitle: 'IS:1786 के सामान्य मानकों से कहीं अधिक परीक्षण ताकि सिविल इंजीनियरों और गृहस्वामियों को मिले पूर्ण सुरक्षा।',
    },
    products: {
      badge: 'सटीक संरचनात्मक उत्पाद श्रृंखला',
      title1: 'हमारी टीएमटी सरिया',
      title2: 'रेंज।',
      subtitle: 'सपनों के आशियाने से लेकर विशाल राजमार्गों और पुलों तक, बलवंत प्रदान करता है हर जरूरत का सही ग्रेड।',
      requestQuote: 'दाम और कोटेशन मांगें',
      viewSpecs: 'विशिष्टताएं देखें',
    },
    process: {
      badge: 'जर्मन थर्मैक्स QST तकनीक',
      title1: 'फौलाद बनने की',
      title2: 'सटीक प्रक्रिया।',
      subtitle: '5 चरणों वाली स्वचालित थर्मो-मैकेनिकल प्रक्रिया, जो बाहरी सतह को मजबूत मार्टेंसाइट और भीतरी कोर को लचीला फेराइट-पर्लाइट बनाती है।',
    },
    quality: {
      badge: 'धातुकर्म मानक एवं NABL प्रयोगशालाएं',
      title1: 'अचूक गुणवत्ता',
      title2: 'बिना किसी समझौते के।',
      subtitle: 'निरंतर ऑनलाइन स्पेक्ट्रो-केमिकल विश्लेषण और भौतिक तनन परीक्षण शून्य अशुद्धता सुनिश्चित करते हैं।',
    },
    technical: {
      badge: 'इंजीनियरिंग अनुपालन एवं मात्रा कैलकुलेटर',
      title1: 'इंजीनियरों एवं ठेकेदारों',
      title2: 'के लिए विशेष।',
      subtitle: 'संरचनात्मक सलाहकारों और बिल्डरों के लिए पूर्ण तकनीकी चार्ट, वजन सहनशीलता तालिका और सटीक मात्रा कैलकुलेटर।',
      estimatorTitle: 'टीएमटी स्टील कैलकुलेटर',
      estimatorSub: 'निर्माण सरिया मात्रा अनुमानक',
      builtUpArea: 'कुल निर्मित क्षेत्र (Sq. Ft.)',
      floors: 'मंजिलों की संख्या (G + N)',
      structureType: 'भवन का प्रकार',
      resOption: 'आवासीय मकान / स्वतंत्र विला',
      commOption: 'व्यावसायिक परिसर / बहुमंजिला इमारत',
      heavyOption: 'भारी औद्योगिक शेड / फैक्ट्री राफ्ट',
      totalSteelNeeded: 'कुल अनुमानित सरिया आवश्यकता',
      totalArea: 'कुल क्षेत्रफल',
      breakdownTitle: 'अनुशंसित व्यास अनुपात विवरण:',
      vaultTitle: 'आधिकारिक प्रमाणन वॉल्ट',
      vaultDesc: 'सत्यापित परीक्षण प्रमाणपत्र, आईएसआई लाइसेंस, रासायनिक रिपोर्ट और स्ट्रक्चरल डिजाइन कैटलॉग डाउनलोड करें।',
    },
    human: {
      badge: 'सरिये से बढ़कर एक विश्वास',
      title1: 'हर सरिया',
      title2: 'बनाता है एक मजबूत',
      title3: 'आशियाना।',
      quote: '“हर नींव के पीछे एक सपना होता है। हर ढांचे के पीछे उसे सबसे मजबूत बनाने का अटूट फैसला होता है।”',
      desc: 'सरिया हमेशा दीवारों और कंक्रीट के अंदर छिपा रहेगा। रंग-रोगन होने के बाद आप इसे कभी दोबारा नहीं देखेंगे। इसीलिए पहले ही दिन सही और असली फौलाद चुनना सबसे महत्वपूर्ण फैसला है।',
      cardTag: 'आपके सपनों के घर के लिए',
      cardQuote: 'घर सिर्फ ईंट और गारे की दीवारें नहीं है, यह वह जगह है जहां परिवार खुशियां मनाते हैं और सपने पलते हैं।',
      stat1Val: '100+ वर्ष',
      stat1Label: 'पीढ़ियों तक चलने वाली संरचना',
      stat2Val: 'शून्य दरारें',
      stat2Label: 'कंक्रीट के साथ अटूट बॉन्डिंग',
    },
    dealerCta: {
      badge: 'डीलर और बिल्डर नेटवर्क',
      title1: 'आइए बनाएं',
      title2: 'एक मजबूत भविष्य।',
      desc: 'अपने नजदीकी अधिकृत जिला वितरक से संपर्क करें या भारत के सबसे तेजी से बढ़ते स्टील नेटवर्क में अधिकृत डीलर के रूप में शामिल हों।',
      findDealerBtn: 'डीलर खोजें',
      becomePartnerBtn: 'डीलरशिप हेतु आवेदन',
      enquireBtn: 'पूछताछ करें',
    },
    finalCta: {
      title1: 'मजबूत बनाओ।',
      title2: 'बलवंत अपनाओ।',
      tagline: '“सरिया नहीं, फौलाद है ये”',
      subtitle: 'अपने मकान, व्यावसायिक प्रोजेक्ट या इंफ्रास्ट्रक्चर को अटूट मजबूती देने के लिए आज ही संपर्क करें।',
      enquireBtn: 'कोटेशन प्राप्त करें',
    },
    footer: {
      desc: 'बलवंत टीएमटी भारत का उच्च-तनन संरचनात्मक सरिया है, जो बिना किसी समझौते के मजबूत नींव के लिए जर्मन थर्मैक्स QST क्वेंचिंग से निर्मित होता है।',
      productsTitle: 'उत्पाद',
      engineeringTitle: 'इंजीनियरिंग',
      connectTitle: 'संपर्क करें',
      address: 'कॉर्पोरेट मुख्यालय एवं मुख्य विनिर्माण संयंत्र, भारत',
      tollFree: 'टोल फ्री',
      locateDealer: 'डीलर खोजें',
      getQuote: 'दाम पूछें',
    },
    common: {
      close: 'बंद करें',
      submit: 'पूछताछ भेजें',
      fullName: 'आपका पूरा नाम *',
      phone: 'मोबाइल नंबर *',
      city: 'शहर / प्रोजेक्ट का स्थान *',
      projectType: 'प्रोजेक्ट का प्रकार',
      tmtGrade: 'वांछित टीएमटी ग्रेड',
      quantity: 'अनुमानित आवश्यकता',
      notes: 'अतिरिक्त विवरण / व्यास',
      searchDistrict: 'शहर, जिला या राज्य खोजें...',
    },
  },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('balwant_lang');
      if (saved === 'hi' || saved === 'en') return saved;
    } catch {
      // fallback
    }
    return 'en';
  });

  useEffect(() => {
    try {
      localStorage.setItem('balwant_lang', language);
    } catch {
      // Ignore storage errors
    }
  }, [language]);

  const value = {
    language,
    setLanguage,
    t: translations[language],
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
