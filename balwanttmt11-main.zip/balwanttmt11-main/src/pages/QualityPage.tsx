import React from 'react';
import {
  ShieldCheck,
  Award,
  Microscope,
  CheckCircle2,
  FileCheck,
  Layers,
  Sparkles,
  Download,
  ArrowUpRight,
  Flame,
  Check,
  ChevronRight,
  AlertTriangle,
  QrCode
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import pristineRebarImg from '../assets/images/tmt_rustfree_bars_final.jpg';
import cleanBundlesImg from '../assets/images/tmt_rustfree_bundles_final.jpg';
import cleanHeroImg from '../assets/images/tmt_rustfree_hero_final.jpg';

interface QualityPageProps {
  onOpenEnquiry: () => void;
  onOpenDealer: () => void;
}

export const QualityPage: React.FC<QualityPageProps> = ({ onOpenEnquiry, onOpenDealer }) => {
  const { language } = useLanguage();

  const qualityTests = [
    {
      title: 'Optical Emission Spectrometry (OES)',
      category: 'Chemical Testing',
      standard: 'IS: 1786 : 2008 & IS: 228',
      desc: 'High-precision 24-channel spectrometer tests every liquid heat for strict control over Carbon (< 0.25%), Sulphur (< 0.040%), Phosphorus (< 0.040%), and Carbon Equivalent (< 0.42%).',
      result: '100% Heat Batch Certified',
    },
    {
      title: 'Universal Testing Machine (UTM) Tensile Test',
      category: 'Mechanical Testing',
      standard: 'IS: 1608 (Part 1) : 2018',
      desc: 'Measures 0.2% Proof Stress (Yield Strength > 550 N/mm²), Ultimate Tensile Strength (> 600 N/mm²), and stress-strain elastic recovery.',
      result: 'UTS / YS Ratio > 1.20',
    },
    {
      title: '180° Cold Bend & Re-Bend Ductility Test',
      category: 'Physical Ductility',
      standard: 'IS: 1599 : 2019',
      desc: 'Rebars are bent 180° around small mandrels (5d/7d) and reverse-bent by 23° after aging in 100°C boiling water for 30 minutes without a single surface crack.',
      result: 'Zero Micro-Fractures',
    },
    {
      title: 'Rib Geometry & Projected Area (AR) Check',
      category: 'Dimensional Accuracy',
      standard: 'IS: 1786 Cl. 5.3',
      desc: 'Digital optical comparators verify transverse rib height, angle (45°-65°), and spacing to ensure Projected Rib Area exceeds 0.075 for 250% stronger concrete grip.',
      result: 'AR > 0.075 Exceeds Standard',
    },
    {
      title: 'Macro-Etch Microstructure Examination',
      category: 'Metallurgical Phase',
      standard: 'ASTM E381',
      desc: 'Cross-sectional nitric acid etching confirms the uniform thickness of the outer tempered Martensite ring and soft, ductile Ferrite-Pearlite core.',
      result: '100% Dual Phase Integrity',
    },
    {
      title: 'Accelerated Salt Spray Corrosion Test',
      category: 'Corrosion Shield (CRS)',
      standard: 'ASTM B117 / IS: 9844',
      desc: 'Subjected to continuous 5% NaCl salt fog mist at 35°C to evaluate resistance against groundwater alkalinity, coastal humidity, and chloride penetration.',
      result: '2.5x Longer Life than Ordinary Rebar',
    },
  ];

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Quality Assurance &amp; BIS Standards</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                NABL CERTIFIED IN-HOUSE METALLURGY LAB
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              RIGID QUALITY <span className="text-[#D9A700]">STANDARDS &amp; TESTING</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Every single batch of Balwant TMT steel undergoes mandatory physical, chemical, and metallurgical testing at our computerized plant laboratory. Zero compromises on strength, ductility, and building safety.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Quality Tests Grid */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between border-b border-amber-200 pb-4 gap-4">
          <div>
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
              Test Battery Protocol
            </span>
            <h2 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              6 STAGES OF LABORATORY VERIFICATION
            </h2>
          </div>
          <button
            onClick={onOpenEnquiry}
            className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase tracking-wider px-5 py-2.5 rounded-xs border border-amber-400 cursor-pointer shadow-xs"
          >
            Request Batch Test Certificate (MTC)
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {qualityTests.map((t, idx) => (
            <div
              key={idx}
              className="bg-white border border-amber-200 p-6 rounded-xs shadow-xs hover:shadow-md hover:border-amber-300 transition-all flex flex-col justify-between text-left"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono-tech bg-amber-100 text-amber-900 px-2 py-0.5 rounded-xs font-bold uppercase">
                    {t.category}
                  </span>
                  <span className="text-[10px] font-mono-tech text-zinc-500 font-semibold">
                    {t.standard}
                  </span>
                </div>
                <h3 className="font-display font-black text-base text-zinc-900 uppercase leading-snug mb-2">
                  {t.title}
                </h3>
                <p className="text-xs text-zinc-600 leading-relaxed mb-4">
                  {t.desc}
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-100 flex items-center justify-between">
                <span className="text-[10px] font-mono-tech text-zinc-500 uppercase font-semibold">Result Benchmark:</span>
                <span className="text-xs font-mono-tech text-emerald-700 font-black flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {t.result}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* 3. Anti-Counterfeit Verification Guide */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md mb-16">
          <div className="max-w-3xl mb-8 text-left">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3 py-1 rounded-xs mb-2">
              <QrCode className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-bold text-amber-900 uppercase">
                Anti-Counterfeiting &amp; Buyer Protection
              </span>
            </div>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              HOW TO IDENTIFY ORIGINAL BALWANT TMT
            </h3>
            <p className="text-zinc-700 text-sm font-medium mt-2">
              Protect your building from substandard or fake re-rolled rebars. Verify these 4 authentic manufacturing hallmarks on every single bar delivered to your site:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
            <div className="bg-white border border-amber-300 p-5 rounded-xs shadow-xs">
              <div className="w-8 h-8 rounded-full bg-[#FFD700] text-black font-black font-display text-sm flex items-center justify-center mb-3">
                01
              </div>
              <h4 className="font-display font-black text-sm text-zinc-900 uppercase mb-1">
                Continuous Brand Embossing
              </h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                The words <strong>"BALWANT TMT Fe 550D"</strong> are hot-rolled and embossed on every meter along the bar.
              </p>
            </div>

            <div className="bg-white border border-amber-300 p-5 rounded-xs shadow-xs">
              <div className="w-8 h-8 rounded-full bg-[#FFD700] text-black font-black font-display text-sm flex items-center justify-center mb-3">
                02
              </div>
              <h4 className="font-display font-black text-sm text-zinc-900 uppercase mb-1">
                Official BIS ISI Hallmark
              </h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Clear BIS (Bureau of Indian Standards) license mark <strong>IS: 1786 : 2008</strong> stamped alongside the brand name.
              </p>
            </div>

            <div className="bg-white border border-amber-300 p-5 rounded-xs shadow-xs">
              <div className="w-8 h-8 rounded-full bg-[#FFD700] text-black font-black font-display text-sm flex items-center justify-center mb-3">
                03
              </div>
              <h4 className="font-display font-black text-sm text-zinc-900 uppercase mb-1">
                Yellow Factory Metal Tag
              </h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Every bundle arrives secured with heavy metal strapping and a tamper-evident yellow metallic inspection tag with heat number.
              </p>
            </div>

            <div className="bg-white border border-amber-300 p-5 rounded-xs shadow-xs">
              <div className="w-8 h-8 rounded-full bg-[#FFD700] text-black font-black font-display text-sm flex items-center justify-center mb-3">
                04
              </div>
              <h4 className="font-display font-black text-sm text-zinc-900 uppercase mb-1">
                100% Rust-Free Clean Gunmetal
              </h4>
              <p className="text-xs text-zinc-600 leading-relaxed">
                Pristine bluish-gray metallic surface, straight bars without bend defects, stored in indoor covered bays.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
