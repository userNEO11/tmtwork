import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  ShieldCheck,
  Send,
  CheckCircle2,
  ChevronRight,
  MessageSquare,
  Building2,
  ArrowUpRight
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const ContactPage: React.FC = () => {
  const { language } = useLanguage();
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    city: '',
    grade: 'Fe 550D',
    tonnage: '10 to 25 MT',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;
    setFormSubmitted(true);
  };

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Contact Us &amp; Factory Sales</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Phone className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                DIRECT MILL SALES &amp; LOGISTICS DESK
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              GET IN TOUCH <span className="text-[#D9A700]">WITH BALWANT</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Reach our factory sales team for wholesale pricing, trailer load dispatches, project tenders, dealer distribution, or technical certifications.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Contact Grid */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          {/* Left Column: Contact Details Cards */}
          <div className="lg:col-span-5 space-y-6 text-left">
            {/* Toll Free Helpline */}
            <div className="bg-white border-2 border-amber-300 p-6 rounded-xs shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-[#FFD700] text-black rounded-xs flex items-center justify-center font-display font-black text-lg">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono-tech text-zinc-500 uppercase font-bold block">
                    All-India Toll Free Line
                  </span>
                  <a
                    href="tel:18001205500"
                    className="font-display font-black text-2xl text-zinc-900 hover:text-amber-700 transition-colors"
                  >
                    1800 120 5500
                  </a>
                </div>
              </div>
              <p className="text-xs text-zinc-600 font-medium">
                Toll-free customer assistance for home builders, architects &amp; contractors (9:00 AM - 8:00 PM).
              </p>
            </div>

              {/* Direct Offices & Contact Helplines */}
              <div className="bg-white border-2 border-amber-300 p-6 rounded-xs shadow-xs space-y-6">
                <div>
                  <span className="font-mono-tech text-xs font-bold text-amber-800 uppercase block mb-1">
                    Official Headquarters &amp; Regional Network
                  </span>
                  <h3 className="font-display font-black text-xl uppercase text-zinc-900 border-b border-amber-200 pb-2">
                    Office Addresses
                  </h3>
                </div>

                {/* 1. Corporate Office */}
                <div className="flex items-start gap-3 bg-amber-50/70 p-3.5 border border-amber-200 rounded-xs">
                  <Building2 className="w-5 h-5 text-amber-800 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono-tech text-xs font-black text-amber-950 uppercase">
                        Corporate Office
                      </span>
                      <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded-xs font-bold uppercase">
                        HQ
                      </span>
                    </div>
                    <span className="text-xs text-zinc-800 leading-relaxed block mt-1 font-medium">
                      4/5 Greater Noida Sector 1, Delhi NCR (201301)
                    </span>
                  </div>
                </div>

                {/* 2. Eastern Zone Office */}
                <div className="flex items-start gap-3 bg-zinc-50 p-3.5 border border-zinc-200 rounded-xs">
                  <MapPin className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-mono-tech text-xs font-bold text-zinc-900 uppercase block">
                      Eastern Zone Office
                    </span>
                    <span className="text-xs text-zinc-700 leading-relaxed block mt-1 font-medium">
                      Plot No 1 Rajamahal Green Town, Kurud Road, Bhilai, Dist- Durg (C.G) 490024
                    </span>
                  </div>
                </div>

                {/* 3. Central Zone Office */}
                <div className="flex items-start gap-3 bg-zinc-50 p-3.5 border border-zinc-200 rounded-xs">
                  <MapPin className="w-5 h-5 text-amber-700 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-mono-tech text-xs font-bold text-zinc-900 uppercase block">
                      Central Zone Office
                    </span>
                    <span className="text-xs text-zinc-700 leading-relaxed block mt-1 font-medium">
                      Gomti Nagar, 226010, Lucknow, Uttar Pradesh
                    </span>
                  </div>
                </div>

                {/* Contact Numbers Section */}
                <div className="pt-2 border-t border-amber-200 space-y-3">
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-amber-800" />
                    <span className="font-mono-tech text-xs font-black text-zinc-900 uppercase">
                      Contact Numbers
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <a
                      href="tel:+918817303963"
                      className="flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xs text-xs font-mono-tech font-bold text-zinc-900 transition-colors group"
                    >
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-700" />
                        <span>+91 8817303963</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-black transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>

                    <a
                      href="tel:+918839838970"
                      className="flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xs text-xs font-mono-tech font-bold text-zinc-900 transition-colors group"
                    >
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-700" />
                        <span>+91 8839838970</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-black transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>

                    <a
                      href="tel:+919202405958"
                      className="flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xs text-xs font-mono-tech font-bold text-zinc-900 transition-colors group"
                    >
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-700" />
                        <span>+91 9202405958</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-black transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>

                    <a
                      href="tel:+919301541867"
                      className="flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xs text-xs font-mono-tech font-bold text-zinc-900 transition-colors group"
                    >
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-700" />
                        <span>+91 9301541867</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-black transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>

                    <a
                      href="tel:+916260928005"
                      className="flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xs text-xs font-mono-tech font-bold text-zinc-900 transition-colors group sm:col-span-2"
                    >
                      <span className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-amber-700" />
                        <span>+91 6260928005</span>
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-black transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>
                  </div>
                </div>

                {/* Email Inquiries */}
                <div className="pt-2 border-t border-amber-200 space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-amber-800" />
                    <span className="font-mono-tech text-xs font-black text-zinc-900 uppercase">
                      Email Addresses
                    </span>
                  </div>
                  <div className="flex flex-col gap-1.5 text-xs font-mono-tech">
                    <a
                      href="mailto:contact@balwanttmt.com"
                      className="text-amber-900 hover:text-black font-bold flex items-center gap-1.5 hover:underline"
                    >
                      <span>contact@balwanttmt.com</span>
                    </a>
                    <a
                      href="mailto:contact@balwantsteelandpower.in"
                      className="text-amber-900 hover:text-black font-bold flex items-center gap-1.5 hover:underline"
                    >
                      <span>contact@balwantsteelandpower.in</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* WhatsApp Quick Chat */}
              <div className="bg-[#25D366]/10 border border-[#25D366]/30 p-5 rounded-xs flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#25D366] text-white rounded-xs flex items-center justify-center">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-display font-black text-sm text-zinc-900 uppercase block">
                      Instant WhatsApp Support
                    </span>
                    <span className="text-xs text-zinc-600 block">
                      Get today's live steel rate on WhatsApp
                    </span>
                  </div>
                </div>
                <a
                  href="https://wa.me/918817303963?text=Hello%20Balwant%20TMT,%20I%20would%20like%20to%20know%20today's%20steel%20price%20and%20stock%20availability."
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#25D366] hover:bg-[#1EBE5D] text-white font-display font-black text-xs uppercase px-4 py-2 rounded-xs shadow-xs cursor-pointer"
                >
                  Chat Now
                </a>
              </div>
          </div>

          {/* Right Column: Factory Price Enquiry Form */}
          <div className="lg:col-span-7 bg-white border-2 border-amber-300 p-6 sm:p-8 rounded-xs shadow-md text-left">
            {formSubmitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-display font-black text-2xl text-zinc-900 uppercase">
                  Thank You, {formData.name}!
                </h3>
                <p className="text-sm text-zinc-600 max-w-md mx-auto">
                  Your inquiry for <strong>{formData.grade}</strong> ({formData.tonnage}) in <strong>{formData.city || 'your city'}</strong> has been routed to our Central Sales Desk. Our sales executive will call you at <strong>{formData.phone}</strong> within 15 minutes with current factory mill rates.
                </p>
                <button
                  onClick={() => setFormSubmitted(false)}
                  className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase py-2 px-5 rounded-xs"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <span className="font-mono-tech text-xs text-amber-800 font-bold uppercase block mb-1">
                    Direct Mill Rate Desk
                  </span>
                  <h3 className="font-display font-black text-2xl text-zinc-900 uppercase">
                    REQUEST FACTORY PRICE QUOTATION
                  </h3>
                  <p className="text-xs text-zinc-600 mt-1 font-medium">
                    Fill out your requirements below to receive a formal computerized proforma quotation with GST breakdown and freight estimation.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Chandra"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Mobile Number (WhatsApp) *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Delivery City / Site *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lucknow / Kanpur"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Required Grade
                    </label>
                    <select
                      value={formData.grade}
                      onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 font-bold"
                    >
                      <option value="Fe 550D">Fe 550D Primary (Flagship)</option>
                      <option value="Fe 500D">Fe 500D Seismic</option>
                      <option value="Fe 550D CRS">Fe 550D CRS (Corrosion Resistant)</option>
                      <option value="Fe 600">Fe 600 Mega Infra</option>
                      <option value="Ready-Made Stirrups">Ready-Made Stirrups</option>
                      <option value="Wire Rods">Wire Rods</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Approx. Tonnage
                    </label>
                    <select
                      value={formData.tonnage}
                      onChange={(e) => setFormData({ ...formData, tonnage: e.target.value })}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 font-bold"
                    >
                      <option value="Under 5 MT">Under 5 MT (Home Build)</option>
                      <option value="5 to 15 MT">5 to 15 MT (Multi-Story)</option>
                      <option value="15 to 50 MT">15 to 50 MT (Commercial)</option>
                      <option value="50+ MT Full Trailer">50+ MT Full Trailer Load</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                    Special Requirements / Specific Diameters (Optional)
                  </label>
                  <textarea
                    rows={3}
                    placeholder="e.g. Need 8mm, 12mm, and 16mm bundle mix for foundation pouring next week..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-sm uppercase tracking-wider py-4 rounded-xs shadow-md border border-amber-400 cursor-pointer flex items-center justify-center gap-2 transition-all hover:scale-102 active:scale-98"
                >
                  <span>Submit for Instant Mill Price Proforma</span>
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
