import React from 'react';
import {
  ShieldCheck,
  Award,
  Layers,
  CheckCircle2,
  Download,
  ArrowUpRight,
  ChevronRight,
  FileText,
  Calculator,
  Flame,
  Check
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface TechnicalPageProps {
  onOpenEnquiry: (grade?: string) => void;
  onOpenDealer: () => void;
  onNavigate?: (page: string) => void;
}

export const TechnicalPage: React.FC<TechnicalPageProps> = ({ onOpenEnquiry, onOpenDealer, onNavigate }) => {
  const { language } = useLanguage();

  const comparisonData = [
    {
      parameter: '0.2% Proof Stress / Yield Strength (YS)',
      isStandardFe500: 'Min 500 N/mm²',
      isStandardFe550D: 'Min 550 N/mm²',
      balwantFe550D: 'Min 550 N/mm² (Avg 580 N/mm²)',
      advantage: '+16% higher load capacity than Fe 500',
    },
    {
      parameter: 'Ultimate Tensile Strength (UTS)',
      isStandardFe500: 'Min 545 N/mm²',
      isStandardFe550D: 'Min 600 N/mm²',
      balwantFe550D: 'Min 600 N/mm² (Avg 645 N/mm²)',
      advantage: 'Greater ultimate safety factor',
    },
    {
      parameter: 'UTS / YS Ratio (Seismic Energy Dissipation)',
      isStandardFe500: 'Min 1.08',
      isStandardFe550D: 'Min 1.10',
      balwantFe550D: 'Min 1.15 to 1.25',
      advantage: 'Prevents sudden brittle collapse during quakes',
    },
    {
      parameter: 'Total Elongation % at Fracture',
      isStandardFe500: 'Min 12.0%',
      isStandardFe550D: 'Min 14.5%',
      balwantFe550D: 'Min 16.0% to 18.5%',
      advantage: 'Exceptional 180° cold bendability',
    },
    {
      parameter: 'Uniform Elongation (Agt %)',
      isStandardFe500: 'Not Specified',
      isStandardFe550D: 'Min 5.0%',
      balwantFe550D: 'Min 6.0% to 7.5%',
      advantage: 'Exceeds High-Seismic Zone V criteria',
    },
    {
      parameter: 'Carbon (C %)',
      isStandardFe500: 'Max 0.30%',
      isStandardFe550D: 'Max 0.25%',
      balwantFe550D: 'Max 0.22% (Ultra-Controlled)',
      advantage: 'Flawless site weldability without preheating',
    },
    {
      parameter: 'Sulphur + Phosphorus (S+P %)',
      isStandardFe500: 'Max 0.105%',
      isStandardFe550D: 'Max 0.075%',
      balwantFe550D: 'Max 0.070%',
      advantage: 'High purity, zero cold-shortness or hot-shortness',
    },
    {
      parameter: 'Projected Rib Area (AR)',
      isStandardFe500: '0.045 - 0.056',
      isStandardFe550D: '0.056',
      balwantFe550D: '0.075 - 0.085',
      advantage: '40% higher mechanical grip with concrete',
    },
  ];

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Civil &amp; Structural Engineering Center</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Layers className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                IS: 1786 : 2008 METALLURGY SPECIFICATION
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              TECHNICAL DATA &amp; <span className="text-[#D9A700]">COMPLIANCE MATRIX</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Comprehensive metallurgical, mechanical, and chemical benchmarks comparing Balwant TMT Fe 550D with national IS: 1786 standards for structural engineers and architects.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Comparative Benchmark Table */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Estimator Tool Launch Banner */}
        {onNavigate && (
          <div className="bg-gradient-to-r from-zinc-900 to-zinc-950 text-white border-2 border-amber-400 p-6 sm:p-8 rounded-xs shadow-lg mb-12 flex flex-col md:flex-row items-center justify-between gap-6 text-left">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 bg-[#FFD700] text-black px-2.5 py-0.5 rounded-xs text-[10px] font-mono-tech font-black uppercase">
                <Calculator className="w-3.5 h-3.5" />
                ONLINE ENGINEERING TOOL
              </div>
              <h3 className="font-display font-black text-2xl text-white uppercase">
                TMT STEEL REQUIREMENT &amp; COST ESTIMATOR
              </h3>
              <p className="text-zinc-300 text-sm max-w-2xl">
                Need to calculate exact steel tonnage (MT), diameter breakdown, and bundle requirements for footings, columns, beams, and slabs?
              </p>
            </div>
            <button
              onClick={() => onNavigate('calculator')}
              className="w-full md:w-auto bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase tracking-wider px-6 py-3.5 rounded-xs border border-amber-300 shadow-md cursor-pointer flex items-center justify-center gap-2 flex-shrink-0"
            >
              <span>Open Estimator Tool</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between border-b border-amber-200 pb-4 gap-4">
          <div>
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
              Specification Benchmarks
            </span>
            <h2 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              IS: 1786 : 2008 VS BALWANT TMT FE 550D
            </h2>
          </div>

          <button
            onClick={() => onOpenEnquiry('Download Full Technical Spec Sheet (TDS)')}
            className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase tracking-wider px-5 py-2.5 rounded-xs border border-amber-400 cursor-pointer flex items-center gap-2 shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Download Engineering Brochure</span>
          </button>
        </div>

        <div className="bg-white border-2 border-amber-300 rounded-xs shadow-md overflow-x-auto mb-16">
          <table className="w-full text-left text-xs sm:text-sm font-mono-tech">
            <thead className="bg-amber-50 text-zinc-900 border-b border-amber-200 font-bold uppercase">
              <tr>
                <th className="py-3.5 px-4">Metallurgical / Mechanical Parameter</th>
                <th className="py-3.5 px-4 text-zinc-600">IS: 1786 Fe 500</th>
                <th className="py-3.5 px-4 text-zinc-600">IS: 1786 Fe 550D</th>
                <th className="py-3.5 px-4 bg-amber-100/70 text-zinc-900 font-black">
                  BALWANT TMT 550D
                </th>
                <th className="py-3.5 px-4 text-emerald-800">Engineering Advantage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200 text-zinc-800">
              {comparisonData.map((row, idx) => (
                <tr key={idx} className="hover:bg-amber-50/40 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-zinc-900">{row.parameter}</td>
                  <td className="py-3.5 px-4 text-zinc-600">{row.isStandardFe500}</td>
                  <td className="py-3.5 px-4 text-zinc-700">{row.isStandardFe550D}</td>
                  <td className="py-3.5 px-4 bg-amber-50 font-black text-amber-950">
                    {row.balwantFe550D}
                  </td>
                  <td className="py-3.5 px-4 text-emerald-700 font-semibold">{row.advantage}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 3. Structural Designer Support */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md text-left">
          <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase mb-3">
            NEED CUSTOM TECHNICAL CALCULATIONS OR CAD PROFILES?
          </h3>
          <p className="text-zinc-700 text-sm font-medium leading-relaxed max-w-3xl mb-6">
            Our Senior Chief Metallurgist and Structural Technical Advisory team assist consulting engineers with seismic ductile detailing (IS 13920:2016), SP 16 design charts, and on-site rebar bend schedules.
          </p>
          <button
            onClick={() => onOpenEnquiry('Structural Advisory Consultation')}
            className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-8 py-3.5 rounded-xs shadow-md border border-amber-400 cursor-pointer flex items-center gap-2"
          >
            <span>Consult Chief Structural Metallurgist</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
};
