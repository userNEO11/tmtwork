import React, { useState } from 'react';
import {
  Flame,
  ShieldCheck,
  Cpu,
  Thermometer,
  Wind,
  Scissors,
  CheckCircle2,
  Play,
  Film,
  Sparkles,
  ArrowUpRight,
  Layers,
  ChevronRight
} from 'lucide-react';
import { PROCESS_STEPS } from '../data/tmtData';
import { useLanguage } from '../context/LanguageContext';
import millImg from '../assets/images/tmt_mill_sparks_bright_1787135359045.jpg';
import cleanSiteImg from '../assets/images/tmt_rustfree_hero_final.jpg';
import cleanRebarImg from '../assets/images/tmt_rustfree_bars_final.jpg';
import cleanBundlesImg from '../assets/images/tmt_rustfree_bundles_final.jpg';

interface ProcessPageProps {
  onOpenEnquiry: () => void;
  onOpenDealer: () => void;
}

export const ProcessPage: React.FC<ProcessPageProps> = ({ onOpenEnquiry, onOpenDealer }) => {
  const { language } = useLanguage();
  const [activeStepIndex, setActiveStepIndex] = useState(2); // default Thermex QST
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const stepImages = [millImg, millImg, cleanRebarImg, cleanSiteImg, cleanBundlesImg];
  const activeStep = PROCESS_STEPS[activeStepIndex] || PROCESS_STEPS[2];

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Thermex® QST Manufacturing Process</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Flame className="w-4 h-4 text-amber-600" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                GERMAN HENNIGSDORFER THERMEX® AUTOMATION
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              THE MAKING OF <span className="text-[#D9A700]">BALWANT TMT</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              From 100% prime virgin DRI iron ore to computerized tandem rolling and rapid water quenching. Explore how state-of-the-art metallurgy gives Balwant steel its trademark high ductility and massive load-bearing strength.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Process Stepper & Interactive Walkthrough */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Step Selector Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-10">
          {PROCESS_STEPS.map((step, idx) => (
            <button
              key={step.step}
              onClick={() => setActiveStepIndex(idx)}
              className={`p-4 rounded-xs border text-left transition-all cursor-pointer ${
                activeStepIndex === idx
                  ? 'bg-[#FFD700] border-amber-400 shadow-md scale-105 font-black text-black'
                  : 'bg-white border-zinc-200 text-zinc-700 hover:border-amber-300 hover:bg-amber-50/50'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-mono-tech text-xs font-bold uppercase opacity-80">
                  STAGE 0{idx + 1}
                </span>
                {idx === 2 && (
                  <span className="text-[9px] bg-black text-[#FFD700] px-1 py-0.5 rounded-xs font-mono-tech font-bold">
                    CORE QST
                  </span>
                )}
              </div>
              <div className="font-display font-black text-sm uppercase leading-snug">
                {step.name}
              </div>
            </button>
          ))}
        </div>

        {/* Selected Step Detailed View */}
        <div className="bg-white border-2 border-amber-300 rounded-xs shadow-md p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          <div className="lg:col-span-7 space-y-6 text-left">
            <div>
              <div className="inline-flex items-center gap-2 bg-amber-100 text-zinc-900 border border-amber-300 px-3 py-1 rounded-xs mb-3 font-mono-tech text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                <span>STEP 0{activeStepIndex + 1} OF 05 • {activeStep.stat}</span>
              </div>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-zinc-900 uppercase tracking-tight">
                {activeStep.name}
              </h2>
              <p className="text-sm font-semibold text-[#D9A700] mt-1 font-mono-tech uppercase">
                {activeStep.highlight}
              </p>
            </div>

            <p className="text-zinc-700 text-sm sm:text-base leading-relaxed">
              {activeStep.description}
            </p>

            <div className="bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <span className="font-mono-tech text-xs text-amber-900 font-bold uppercase block mb-1">
                Metallurgical Key Benchmark
              </span>
              <p className="text-xs text-zinc-800 font-medium leading-relaxed">
                {activeStep.stat} — Controlled automated processing ensuring superior ductility, uniform cross-sectional ribs, and 100% prime virgin steel integrity.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setIsVideoModalOpen(true)}
                className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs shadow-sm flex items-center gap-2 border border-amber-400 cursor-pointer transition-all hover:scale-105 active:scale-95"
              >
                <Film className="w-4 h-4 text-black" />
                <span>Watch 1150°C Mill Reel</span>
              </button>

              <button
                onClick={onOpenEnquiry}
                className="bg-white hover:bg-zinc-100 text-zinc-900 border border-zinc-300 hover:border-amber-400 font-display font-bold text-xs sm:text-sm uppercase tracking-wider px-5 py-3.5 rounded-xs transition-all flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <span>Request Mill Visit</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative bg-zinc-900 rounded-xs overflow-hidden border border-amber-300 shadow-xl group">
              <img
                src={stepImages[activeStepIndex]}
                alt={activeStep.name}
                className="w-full h-80 sm:h-96 object-cover object-center filter brightness-100 contrast-[1.05] saturate-[1.1] transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md border border-amber-200 p-3 rounded-xs shadow-md">
                <div className="flex items-center justify-between text-xs font-mono-tech">
                  <span className="text-zinc-600 font-semibold">Thermal &amp; Process Stat</span>
                  <span className="text-amber-800 font-black">{activeStep.stat}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono-tech mt-1">
                  <span className="text-zinc-600 font-semibold">Process Automation</span>
                  <span className="text-emerald-700 font-bold">100% PLC Controlled</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Dual-Phase Microstructure Deep Dive */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md mb-16">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
              Microstructural Cross-Section
            </span>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              WHY THE DUAL-PHASE METALLURGY MATTERS
            </h3>
            <p className="text-zinc-700 text-sm font-medium mt-2">
              Unlike ordinary CTD or non-QST rebars which crack during bending, Balwant TMT's patented dual-phase cross-section provides the ultimate balance of surface hardness and core elasticity.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Box 1: Outer Rim */}
            <div className="bg-white border border-amber-300 p-6 rounded-xs shadow-xs text-left">
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck className="w-5 h-5 text-amber-700" />
                <h4 className="font-display font-black text-lg text-zinc-900 uppercase">
                  Outer Rim: Tempered Martensite
                </h4>
              </div>
              <p className="text-xs text-zinc-700 leading-relaxed mb-4">
                Formed during intensive water-quenching in the Thermex® chamber. Provides maximum yield strength (550+ N/mm²), high fire resistance up to 600°C, and exceptional wear resistance.
              </p>
              <div className="flex items-center justify-between text-xs font-mono-tech bg-amber-50 p-2.5 rounded-xs border border-amber-200">
                <span className="text-zinc-600 font-bold">Yield Strength</span>
                <span className="text-zinc-900 font-black">&gt; 550 N/mm²</span>
              </div>
            </div>

            {/* Box 2: Inner Core */}
            <div className="bg-white border border-amber-300 p-6 rounded-xs shadow-xs text-left">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h4 className="font-display font-black text-lg text-zinc-900 uppercase">
                  Inner Core: Ferrite-Pearlite
                </h4>
              </div>
              <p className="text-xs text-zinc-700 leading-relaxed mb-4">
                Maintains a ductile crystal structure through controlled atmospheric self-tempering. Absorbs massive cyclical shockwaves during earthquakes and allows seamless 180° cold bending without cracking.
              </p>
              <div className="flex items-center justify-between text-xs font-mono-tech bg-emerald-50 p-2.5 rounded-xs border border-emerald-200">
                <span className="text-zinc-600 font-bold">Elongation Ductility</span>
                <span className="text-emerald-800 font-black">&gt; 16.0% (High Ductility)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Video Modal */}
      {isVideoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white border-2 border-amber-400 rounded-xs shadow-2xl max-w-4xl w-full p-6 text-zinc-900 relative">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-200 mb-4">
              <div className="flex items-center gap-2 font-display font-black text-lg uppercase">
                <Flame className="w-5 h-5 text-amber-600" />
                <span>Balwant Continuous Hot Rolling Mill Reel</span>
              </div>
              <button
                onClick={() => setIsVideoModalOpen(false)}
                className="text-zinc-500 hover:text-black font-bold p-1 cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            <div className="relative aspect-video bg-zinc-950 rounded-xs overflow-hidden mb-4">
              <video
                src="https://assets.mixkit.co/videos/preview/mixkit-molten-steel-being-poured-into-a-mold-41793-large.mp4"
                autoPlay
                controls
                loop
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex justify-between items-center text-xs font-mono-tech text-zinc-600">
              <span>Balwant TMT • Automated Tandem Rolling &amp; Thermex® QST Quenching</span>
              <button
                onClick={() => {
                  setIsVideoModalOpen(false);
                  onOpenEnquiry();
                }}
                className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black uppercase px-4 py-2 rounded-xs cursor-pointer"
              >
                Request Quotation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
