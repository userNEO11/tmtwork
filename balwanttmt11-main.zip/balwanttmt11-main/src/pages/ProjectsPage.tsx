import React, { useState } from 'react';
import {
  Building2,
  ShieldCheck,
  Award,
  CheckCircle2,
  ArrowUpRight,
  ChevronRight,
  Layers,
  MapPin,
  Flame,
  PhoneCall
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import expresswayImg from '../assets/images/balwant_infra_slider_1787645636350.jpg';
import metroImg from '../assets/images/balwant_fe550d_slider_1787645576016.jpg';
import barrageImg from '../assets/images/balwant_infra_site_pure_1787135693938.jpg';
import highriseImg from '../assets/images/balwant_site_indian_engineers_1786953214603.jpg';
import logisticsImg from '../assets/images/balwant_bundles_slider_1787645616843.jpg';
import healthcareImg from '../assets/images/balwant_indian_infrastructure_1786953243770.jpg';

interface ProjectsPageProps {
  onOpenEnquiry: (grade?: string) => void;
  onOpenDealer: () => void;
}

interface ProjectItem {
  id: string;
  title: string;
  category: 'infra' | 'metro' | 'highrise' | 'commercial';
  location: string;
  tonnage: string;
  gradeUsed: string;
  description: string;
  image: string;
  client: string;
  keyHighlight: string;
}

export const ProjectsPage: React.FC<ProjectsPageProps> = ({ onOpenEnquiry, onOpenDealer }) => {
  const { language } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const projects: ProjectItem[] = [
    {
      id: 'p1',
      title: 'Purvanchal Expressway Heavy Viaduct Bridges',
      category: 'infra',
      location: 'Uttar Pradesh Highway Corridor',
      tonnage: '8,400 MT',
      gradeUsed: 'Balwant Fe 550D & Fe 600',
      description: 'Massive reinforcement of multi-span river crossings, deep pile foundation cages, and heavy load-distribution bridge deck slabs.',
      image: expresswayImg,
      client: 'State Highway Authority & EPC Partner',
      keyHighlight: 'Engineered for 100-Year Design Fatigue Life',
    },
    {
      id: 'p2',
      title: 'Kanpur & Lucknow Metro Rail Elevated Viaducts',
      category: 'metro',
      location: 'Kanpur & Lucknow Metro Corridors',
      tonnage: '5,200 MT',
      gradeUsed: 'Balwant Fe 550D High Ductility',
      description: 'High-seismic reinforcement deployed in elevated viaduct piers, station portal beams, and heavy seismic energy dissipation bearings.',
      image: metroImg,
      client: 'Metro Rail Corporation',
      keyHighlight: 'Zone IV High Seismic Energy Dissipation',
    },
    {
      id: 'p3',
      title: 'Ganga Barrage River Bridge & Flood Protection Wall',
      category: 'infra',
      location: 'Kanpur Ganga River Basin',
      tonnage: '3,600 MT',
      gradeUsed: 'Balwant Fe 550D CRS (Corrosion Resistant)',
      description: 'Corrosion-resistant steel bars deployed in underwater foundation piers, spillway aprons, and retaining guide walls exposed to continuous moisture.',
      image: barrageImg,
      client: 'Irrigation & Flood Control Department',
      keyHighlight: 'Accelerated ASTM B117 Salt-Spray Certified',
    },
    {
      id: 'p4',
      title: 'Grand High-Rise Residential Towers (G+32)',
      category: 'highrise',
      location: 'Lucknow NCR Sector 7',
      tonnage: '4,100 MT',
      gradeUsed: 'Balwant Fe 550D Primary Rebar',
      description: 'High-tensile rebar reinforcement across 4 luxury residential skyscraper towers with deep basement retaining diaphragms and transfer girders.',
      image: highriseImg,
      client: 'Leading Real Estate Developers',
      keyHighlight: 'Zero Micro-Crack 180° Column Ties',
    },
    {
      id: 'p5',
      title: 'Mega Industrial Logistic Park & Warehouses',
      category: 'commercial',
      location: 'GIDA Gorakhpur',
      tonnage: '2,800 MT',
      gradeUsed: 'Balwant Fe 550D & Wire Rods',
      description: 'Heavy floor slab reinforcement with high-tolerance steel mesh and heavy machinery foundation blocks engineered for vibration damping.',
      image: logisticsImg,
      client: 'National Logistics Hub',
      keyHighlight: 'Heavy Dynamic Vibration Resistance',
    },
    {
      id: 'p6',
      title: 'Multi-Speciality Super Healthcare Complex',
      category: 'commercial',
      location: 'Varanasi Medical District',
      tonnage: '3,200 MT',
      gradeUsed: 'Balwant Fe 550D Seismic Grade',
      description: 'Critical hospital structure engineered for uninterrupted post-earthquake structural stability with heavy shear wall rebars.',
      image: healthcareImg,
      client: 'Healthcare Infrastructure Trust',
      keyHighlight: 'Maximum Post-Disaster Structural Safety',
    },
  ];

  const filteredProjects = activeCategory === 'all'
    ? projects
    : projects.filter((p) => p.category === activeCategory);

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Landmark Projects &amp; Civil Engineering</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Building2 className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                18,200+ METRIC TONNES POWERING MEGA STRUCTURES
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              LANDMARK INFRASTRUCTURE <span className="text-[#D9A700]">PROJECTS</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              From critical elevated metro corridors to state expressways, bridges, and high-rise commercial towers. Discover why India's leading civil contractors trust Balwant TMT steel.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Category Filters & Project Showcase */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-wrap gap-2.5 mb-10 border-b border-amber-200 pb-4">
          {[
            { id: 'all', label: 'All Landmark Projects' },
            { id: 'infra', label: 'Expressways & Bridges' },
            { id: 'metro', label: 'Metro Rail & Viaducts' },
            { id: 'highrise', label: 'High-Rise Towers' },
            { id: 'commercial', label: 'Industrial & Commercial' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id)}
              className={`px-5 py-2.5 rounded-xs font-display font-black text-xs sm:text-sm uppercase tracking-wider transition-all cursor-pointer border ${
                activeCategory === tab.id
                  ? 'bg-[#FFD700] text-black border-amber-400 shadow-sm scale-105'
                  : 'bg-white text-zinc-700 border-zinc-200 hover:border-amber-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredProjects.map((p) => (
            <div
              key={p.id}
              className="bg-white border border-amber-200 rounded-xs shadow-xs overflow-hidden hover:shadow-md hover:border-amber-300 transition-all flex flex-col justify-between text-left group"
            >
              <div>
                <div className="relative aspect-[16/10] overflow-hidden bg-zinc-900">
                  <img
                    src={p.image}
                    alt={p.title}
                    className="w-full h-full object-cover object-center filter brightness-100 contrast-[1.05] saturate-[1.1] transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md border border-amber-300 px-2.5 py-1 rounded-xs shadow-xs">
                    <span className="font-mono-tech text-[10px] font-black text-amber-900 uppercase">
                      {p.tonnage} SUPPLIED
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <div className="flex items-center gap-1.5 text-xs text-amber-300 font-mono-tech">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{p.location}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-display font-black text-lg text-zinc-900 uppercase leading-snug mb-2">
                    {p.title}
                  </h3>
                  <p className="text-xs text-zinc-600 leading-relaxed mb-4">
                    {p.description}
                  </p>

                  <div className="space-y-1.5 bg-[#FFFDF0] p-3 rounded-xs border border-amber-200 text-xs font-mono-tech mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Grade Deployed:</span>
                      <span className="text-zinc-900 font-bold">{p.gradeUsed}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-500">Benchmark:</span>
                      <span className="text-emerald-700 font-bold">{p.keyHighlight}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={() => onOpenEnquiry(`Project Inquiry: ${p.title}`)}
                  className="w-full bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase py-2.5 rounded-xs border border-amber-400 cursor-pointer flex items-center justify-center gap-1.5 transition-all shadow-xs"
                >
                  <span>Request Project Technical Specs</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* 3. Bulk Order Commercial Tender Banner */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-left space-y-2 max-w-2xl">
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              HAVE A COMMERCIAL OR INFRASTRUCTURE TENDER?
            </h3>
            <p className="text-zinc-700 text-sm font-medium">
              Our dedicated Institutional Sales Division provides direct mill billing, custom length cutting, priority trailer dispatch, and on-site NABL batch test certificates for projects over 50 MT.
            </p>
          </div>

          <button
            onClick={() => onOpenEnquiry('Bulk Infrastructure Tender')}
            className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-sm uppercase tracking-wider px-8 py-4 rounded-xs shadow-md border border-amber-400 cursor-pointer flex items-center gap-2 whitespace-nowrap"
          >
            <span>Contact Institutional Sales</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </section>
    </div>
  );
};
