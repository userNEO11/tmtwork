import React from 'react';
import { HeroMediaSlider } from '../components/HeroMediaSlider';
import { HeroTopBanner } from '../components/HeroTopBanner';
import { HeroSection } from '../components/HeroSection';
import { BrandStatement } from '../components/BrandStatement';
import { ChairmanMessageSection } from '../components/ChairmanMessageSection';
import { WhyBalwantSection } from '../components/WhyBalwantSection';
import { SteelInMotion } from '../components/SteelInMotion';
import { ProductRangeSection } from '../components/ProductRangeSection';
import { ProcessSection } from '../components/ProcessSection';
import { QualitySection } from '../components/QualitySection';
import { ProjectsGallery } from '../components/ProjectsGallery';
import { HumanConnectionSection } from '../components/HumanConnectionSection';
import { DealerCtaSection } from '../components/DealerCtaSection';
import { KnowledgeSection } from '../components/KnowledgeSection';
import { FinalCtaSection } from '../components/FinalCtaSection';
import { ProductGrade } from '../data/tmtData';
import { Calculator, ArrowUpRight } from 'lucide-react';

interface HomePageProps {
  onOpenEnquiry: (grade?: string) => void;
  onOpenDealer: () => void;
  onNavigate: (page: string) => void;
  onSelectProduct: (product: ProductGrade) => void;
  onOpenArticle: (articleId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onOpenEnquiry,
  onOpenDealer,
  onNavigate,
  onSelectProduct,
  onOpenArticle,
}) => {
  return (
    <div className="flex flex-col w-full">
      {/* 1. Dynamic Image & Video Media Slider immediately below Navbar */}
      <HeroMediaSlider
        onOpenEnquiry={onOpenEnquiry}
        onOpenDealer={onOpenDealer}
      />

      {/* 2. Prominent Information Section below the Slider */}
      <HeroTopBanner
        onOpenEnquiry={onOpenEnquiry}
        onOpenDealer={onOpenDealer}
      />

      {/* 3. Hero Fe 550D Detail Section */}
      <HeroSection
        onOpenEnquiry={() => onOpenEnquiry('Fe 550D')}
        onExploreProducts={() => onNavigate('products')}
      />

      {/* 4. Brand Statement "सरिया नही, फौलाद है ये" */}
      <BrandStatement onOpenEnquiry={() => onOpenEnquiry()} />

      {/* 5. Full Chairman's Desk Message Section with Genuine Photo */}
      <ChairmanMessageSection
        onOpenEnquiry={() => onOpenEnquiry("Chairman's Desk Direct")}
        onOpenDealer={onOpenDealer}
      />

      {/* 6. Quick Interactive TMT Estimator Banner Card */}
      <section className="py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 text-white border-2 border-amber-400 p-6 sm:p-8 rounded-xs shadow-md hover:shadow-lg transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-left">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-mono-tech font-bold text-black bg-[#FFD700] px-2.5 py-0.5 rounded-xs">
                <Calculator className="w-3.5 h-3.5" />
                ONLINE TOOL
              </span>
              <span className="text-xs font-mono-tech text-amber-300 uppercase">IS 456 Compliant</span>
            </div>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-white uppercase tracking-tight mb-2">
              TMT STEEL ESTIMATE CALCULATOR
            </h3>
            <p className="text-zinc-300 text-sm leading-relaxed">
              Calculate total steel tonnage (MT), diameter-wise bundle breakdown (8mm to 32mm), and estimated cost for your home or construction project.
            </p>
          </div>
          <button
            onClick={() => onNavigate('calculator')}
            className="flex-shrink-0 inline-flex items-center justify-center gap-2 bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs border border-amber-300 shadow-md transition-all cursor-pointer"
          >
            <span>Launch Calculator</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 7. Why Balwant 4 Pillars */}
      <WhyBalwantSection
        onOpenEnquiry={() => onOpenEnquiry()}
        onOpenDealer={onOpenDealer}
      />

      {/* 8. Steel in Motion (Interactive Metallurgy Visualizer) */}
      <SteelInMotion onExploreTech={() => onNavigate('process')} />

      {/* 9. Product Range Overview */}
      <ProductRangeSection
        onSelectProduct={(product) => {
          onSelectProduct(product);
          onNavigate('products');
        }}
        onOpenEnquiry={() => onOpenEnquiry()}
      />

      {/* 10. German Thermex QST Process Section */}
      <ProcessSection />

      {/* 11. Quality Assurance & BIS Certification */}
      <QualitySection />

      {/* 12. Landmark Infrastructure Projects Gallery */}
      <ProjectsGallery />

      {/* 13. Human Connection (Builders, Engineers, Homeowners) */}
      <HumanConnectionSection onOpenEnquiry={() => onOpenEnquiry()} />

      {/* 14. Dealer Network CTA Banner */}
      <DealerCtaSection onOpenDealerLocator={onOpenDealer} />

      {/* 15. Knowledge & Engineering Articles */}
      <KnowledgeSection onOpenArticle={onOpenArticle} />

      {/* 16. Final Call to Action */}
      <FinalCtaSection
        onOpenEnquiry={() => onOpenEnquiry()}
        onOpenDealer={onOpenDealer}
      />
    </div>
  );
};
