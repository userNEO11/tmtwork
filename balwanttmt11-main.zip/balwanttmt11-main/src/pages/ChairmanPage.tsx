import React from 'react';
import {
  Quote,
  ShieldCheck,
  Award,
  Flame,
  CheckCircle2,
  Phone,
  Mail,
  ChevronRight,
  ArrowUpRight,
  Building2,
  Sparkles,
  MapPin,
  TrendingUp,
  Users,
  Target,
  Factory
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import chairmanImg from '../assets/images/chairmandesk.jpeg';
import rebarImg from '../assets/images/tmt_rustfree_bars_final.jpg';
import bundlesImg from '../assets/images/tmt_rustfree_bundles_final.jpg';

interface ChairmanPageProps {
  onOpenEnquiry: (topic?: string) => void;
  onOpenDealer: () => void;
}

export const ChairmanPage: React.FC<ChairmanPageProps> = ({
  onOpenEnquiry,
  onOpenDealer,
}) => {
  const { language } = useLanguage();

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Page Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden text-left">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">
              {language === 'hi' ? 'चेयरमैन का संदेश' : "Chairman's Message"}
            </span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Quote className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                {language === 'hi' ? 'नेतृत्व एवं संस्थापकीय विजन' : 'LEADERSHIP & NATIONAL VISION'}
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              CHAIRMAN'S <span className="text-[#D9A700]">MESSAGE</span>
            </h1>

            <p className="text-zinc-800 text-lg sm:text-xl leading-relaxed font-bold">
              Building Strength. Expanding Reach. Growing With India.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Main Executive Letter Section */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-left">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-16">
          {/* Executive Portrait Card (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="relative bg-white rounded-xs border-2 border-amber-400 p-2 shadow-2xl">
              <div className="w-full flex items-center justify-center">
                <img
                  src={chairmanImg}
                  alt="P.N Singh - Chairman (Balwant Steel and Power An associate Singh Aluminium Company Limited)"
                  className="w-full h-auto object-contain block rounded-xs"
                  loading="eager"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Corporate Executive Information Plate */}
              <div className="mt-3.5 pt-3 border-t border-amber-200 bg-amber-50/70 p-4 rounded-xs text-left">
                <div className="font-display font-black text-zinc-950 text-2xl uppercase tracking-tight leading-tight">
                  P.N Singh
                </div>
                <div className="mt-1.5">
                  <span className="inline-flex items-center gap-1.5 bg-amber-700 text-white px-2.5 py-0.5 rounded-xs text-[11px] font-mono-tech font-black uppercase">
                    CHAIRMAN
                  </span>
                </div>
                <h3 className="font-display font-bold text-base uppercase tracking-tight text-amber-950 leading-tight mt-1.5">
                  BALWANT STEEL AND POWER
                </h3>
                <div className="font-mono-tech text-xs font-bold text-zinc-700 uppercase tracking-wide mt-1.5">
                  An Associate
                </div>
                <h3 className="font-display font-bold text-base uppercase tracking-tight text-amber-950 leading-tight mt-0.5">
                  SINGH ALUMINIUM COMPANY LIMITED
                </h3>
              </div>
            </div>

            {/* Chairman's Direct Corporate Contact Card */}
            <div className="bg-white border-2 border-amber-300 p-6 rounded-xs shadow-md space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-amber-200">
                <Building2 className="w-4 h-4 text-amber-700" />
                <span className="font-mono-tech text-xs font-black text-zinc-900 uppercase">
                  DIRECT CHAIRMAN SECRETARIAT DESK
                </span>
              </div>

              <div className="space-y-2 text-xs font-mono-tech text-zinc-700">
                <div className="flex items-start gap-2">
                  <Building2 className="w-3.5 h-3.5 text-amber-700 flex-shrink-0 mt-0.5" />
                  <span>Corporate Office: 4/5 Greater Noida Sector 1, Delhi NCR (201301)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                  <a href="tel:+918839838970" className="hover:text-amber-900 font-bold">
                    Direct Line: +91 8839838970 / +91 8817303963
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                  <a href="mailto:contact@balwanttmt.com" className="hover:text-amber-900 font-bold">
                    Email: contact@balwanttmt.com
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Factory className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                  <span>Zonal Offices: Bhilai (C.G) • Lucknow (U.P)</span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={() => onOpenEnquiry("Chairman's Desk Direct Message")}
                  className="w-full bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase tracking-wider py-2.5 rounded-xs border border-amber-400 cursor-pointer shadow-xs"
                >
                  Send Message to Chairman's Desk
                </button>
              </div>
            </div>
          </div>

          {/* Letter & Founding Creed (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white border-2 border-amber-300 p-6 sm:p-10 rounded-xs shadow-lg text-left relative overflow-hidden">
              <div className="absolute top-4 right-4 text-amber-100/60 pointer-events-none">
                <Quote className="w-24 h-24 text-amber-200/50" />
              </div>

              <div className="relative z-10">
                {/* Vision Headline Banner */}
                <div className="bg-gradient-to-r from-amber-500/15 via-yellow-500/20 to-amber-500/15 border-l-4 border-amber-600 p-4 sm:p-5 rounded-xs mb-6">
                  <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-widest block mb-1">
                    FOUNDATIONAL CREED &amp; NATIONAL VISION
                  </span>
                  <p className="font-display font-black text-xl sm:text-2xl text-zinc-900 italic">
                    “Quality, consistency and trust are the foundation of every lasting structure.”
                  </p>
                </div>

                {/* Exact Chairman Message Body */}
                <div className="space-y-4 text-zinc-800 text-sm sm:text-base leading-relaxed font-sans font-normal">
                  <p className="font-medium text-zinc-950 bg-amber-50/70 p-3.5 rounded-xs border border-amber-200">
                    At <strong>Balwant TMT</strong>, our journey of more than five decades in the steel industry has been built on a simple belief — <strong>quality, consistency and trust</strong> are the foundation of every lasting structure.
                  </p>

                  <p>
                    Today, as we look ahead, our focus is on strengthening our manufacturing capabilities, expanding our distribution network and making <strong>Balwant TMT</strong> accessible to a wider market across India.
                  </p>

                  <p>
                    Our long-term vision is ambitious. We aim to build our presence across <strong>29 states and 8 Union Territories</strong>, establish a strong network of <strong>500+ distributors and 50,000+ dealers</strong>, and expand our dealership reach across all <strong>808 districts of India</strong>. We have also set a target of achieving <strong>60 Lakh ( 6 million ) Metric tonnes per year by 2027</strong>.
                  </p>

                  <p>
                    With manufacturing operations associated with <strong>Bhilai, Raipur, Raigarh and Rourkela</strong>, we are building the capabilities and partnerships required to support this growth.
                  </p>

                  <p>
                    Our commitment, however, goes beyond numbers. Every expansion must be supported by quality manufacturing, responsible business practices, strong technology and long-term relationships with our dealers, distributors, customers and business partners.
                  </p>

                  <p>
                    India's growth is creating new opportunities every day. We see our responsibility as not only growing with this development, but contributing to it by delivering reinforcement steel that people can depend on.
                  </p>

                  <p className="text-zinc-900 font-semibold italic text-base sm:text-lg">
                    Our vision is clear — to take Balwant TMT from a strong regional presence to a trusted national steel brand.
                  </p>
                </div>

                {/* Signature Block */}
                <div className="mt-8 pt-6 border-t border-amber-200 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                  <div>
                    <span className="font-display font-black text-2xl text-zinc-900 uppercase block leading-tight">
                      P.N Singh
                    </span>
                    <span className="font-mono-tech text-xs text-amber-900 font-bold uppercase block mt-0.5">
                      CHAIRMAN
                    </span>
                    <span className="font-display font-bold text-sm text-zinc-800 uppercase block mt-1">
                      Balwant Steel and Power
                    </span>
                    <span className="text-xs font-bold text-zinc-700 block uppercase tracking-wide mt-1">
                      An Associate
                    </span>
                    <span className="font-display font-bold text-sm text-zinc-800 uppercase block mt-0.5">
                      Singh Aluminium Company Limited
                    </span>
                  </div>

                  <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-300 px-3 py-1.5 rounded-xs">
                    <ShieldCheck className="w-4 h-4 text-amber-700" />
                    <span className="font-mono-tech text-xs font-black text-amber-900 uppercase">
                      5+ DECADES OF EXCELLENCE
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3. The 4 Key Targets of National Growth */}
        <div className="mb-16">
          <div className="mb-8 text-left">
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
              Growth Targets &amp; Milestones
            </span>
            <h2 className="font-display font-black text-3xl sm:text-4xl text-zinc-900 uppercase tracking-tight">
              SCALING NATIONWIDE TO BUILD A STRONGER INDIA
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white border-2 border-amber-200 hover:border-amber-400 p-6 rounded-xs shadow-sm transition-all text-left">
              <div className="w-12 h-12 bg-amber-100 rounded-xs flex items-center justify-center text-amber-800 font-black mb-4">
                <MapPin className="w-6 h-6 text-amber-800" />
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 uppercase mb-1">
                29 STATES &amp; 8 UTs
              </div>
              <h3 className="font-mono-tech font-bold text-xs text-amber-800 uppercase mb-2">
                Pan-India Footprint
              </h3>
              <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed">
                Expanding availability of high-tensile Fe 550D TMT steel across every state and union territory in India.
              </p>
            </div>

            <div className="bg-white border-2 border-amber-200 hover:border-amber-400 p-6 rounded-xs shadow-sm transition-all text-left">
              <div className="w-12 h-12 bg-amber-100 rounded-xs flex items-center justify-center text-amber-800 font-black mb-4">
                <Building2 className="w-6 h-6 text-amber-800" />
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 uppercase mb-1">
                808 DISTRICTS
              </div>
              <h3 className="font-mono-tech font-bold text-xs text-amber-800 uppercase mb-2">
                Complete Territorial Reach
              </h3>
              <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed">
                Establishing direct supply lines and dedicated stocking yards across all 808 districts nationwide.
              </p>
            </div>

            <div className="bg-white border-2 border-amber-200 hover:border-amber-400 p-6 rounded-xs shadow-sm transition-all text-left">
              <div className="w-12 h-12 bg-amber-100 rounded-xs flex items-center justify-center text-amber-800 font-black mb-4">
                <Users className="w-6 h-6 text-amber-800" />
              </div>
              <div className="font-display font-black text-xl text-zinc-900 uppercase mb-1">
                500+ DISTRIBUTORS &amp; 50,000+ DEALERS
              </div>
              <h3 className="font-mono-tech font-bold text-xs text-amber-800 uppercase mb-2">
                Strong Distribution Network
              </h3>
              <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed">
                Nurturing transparent, long-term partnerships with 500+ distributors and 50,000+ authorized building material dealers.
              </p>
            </div>

            <div className="bg-white border-2 border-amber-200 hover:border-amber-400 p-6 rounded-xs shadow-sm transition-all text-left">
              <div className="w-12 h-12 bg-amber-100 rounded-xs flex items-center justify-center text-amber-800 font-black mb-4">
                <TrendingUp className="w-6 h-6 text-amber-800" />
              </div>
              <div className="font-display font-black text-xl text-zinc-900 uppercase mb-1">
                60 LAKH (6 MILLION) METRIC TONNES
              </div>
              <h3 className="font-mono-tech font-bold text-xs text-amber-800 uppercase mb-2">
                Annual Sales Volume Target (2027)
              </h3>
              <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed">
                Targeting 60 Lakh (6 Million) Metric Tonnes of annual steel dispatches backed by strategic manufacturing operations in Bhilai, Raipur, Raigarh and Rourkela.
              </p>
            </div>
          </div>
        </div>

        {/* 4. Manufacturing Facility & Call to Action Banner */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-10 rounded-xs shadow-md text-left flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block">
              BALWANT STEEL AND POWER
            </span>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              BECOME A PART OF OUR NATIONAL EXPANSION
            </h3>
            <p className="text-zinc-700 text-sm font-medium leading-relaxed">
              Join as 500+ distributors and 50,000+ dealers or connect directly with our corporate sales desk for project supply, tenders, and institutional inquiries.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto flex-wrap">
            <button
              onClick={onOpenDealer}
              className="w-full sm:w-auto bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-5 py-3.5 rounded-xs border border-amber-400 shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Apply for Dealership</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onOpenEnquiry('Distributorship Application')}
              className="w-full sm:w-auto bg-zinc-900 hover:bg-black text-white font-display font-black text-xs sm:text-sm uppercase tracking-wider px-5 py-3.5 rounded-xs border border-zinc-800 shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Apply for Distributorship</span>
              <ArrowUpRight className="w-4 h-4 text-[#FFD700]" />
            </button>
            <button
              onClick={() => onOpenEnquiry('Factory Direct Purchase')}
              className="w-full sm:w-auto bg-white hover:bg-zinc-100 text-zinc-900 border border-zinc-300 font-display font-bold text-xs sm:text-sm uppercase tracking-wider px-5 py-3.5 rounded-xs shadow-xs cursor-pointer text-center"
            >
              <span>Corporate Sales Desk</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
