import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Search,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Truck,
  ArrowUpRight,
  ChevronRight,
  Send,
  MessageSquare,
  Award
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface DealersPageProps {
  onOpenEnquiry: (grade?: string) => void;
}

interface DealerItem {
  id: string;
  name: string;
  contactPerson: string;
  city: string;
  district: string;
  address: string;
  phone: string;
  altPhone: string;
  stockGrades: string[];
  deliveryCapacity: string;
  isSuperStockist?: boolean;
}

export const DealersPage: React.FC<DealersPageProps> = ({ onOpenEnquiry }) => {
  const { language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCityFilter, setSelectedCityFilter] = useState('All');
  const [dealershipSubmitted, setDealershipSubmitted] = useState(false);

  // Form State
  const [partnerName, setPartnerName] = useState('');
  const [partnerPhone, setPartnerPhone] = useState('');
  const [partnerCity, setPartnerCity] = useState('');
  const [partnerExperience, setPartnerExperience] = useState('');

  const dealersList: DealerItem[] = [
    {
      id: 'd1',
      name: 'M/s Balwant Iron & Steel Traders',
      contactPerson: 'Shri Rajesh Gupta',
      city: 'Kanpur',
      district: 'Kanpur Nagar',
      address: 'Plot No. 44, Fazalganj Industrial Area, Kanpur, UP - 208012',
      phone: '+91 94150 18888',
      altPhone: '+91 98390 18888',
      stockGrades: ['Fe 550D', 'Fe 600', 'Stirrups', 'Wire Rods'],
      deliveryCapacity: 'Same-day 50 MT dispatch',
      isSuperStockist: true,
    },
    {
      id: 'd2',
      name: 'Awadh Steel Corporation',
      contactPerson: 'Vikram Singh',
      city: 'Lucknow',
      district: 'Lucknow',
      address: 'Shop No. 12, Transport Nagar Main Road, Lucknow, UP - 226012',
      phone: '+91 94500 22334',
      altPhone: '+91 98380 44556',
      stockGrades: ['Fe 550D', 'Fe 500D', 'Fe 550D CRS'],
      deliveryCapacity: 'Within 4 hours in Lucknow NCR',
      isSuperStockist: true,
    },
    {
      id: 'd3',
      name: 'Kashi Vishwanath Steel Depot',
      contactPerson: 'Manoj Tripathi',
      city: 'Varanasi',
      district: 'Varanasi',
      address: 'Chandpur Industrial Estate, Grand Trunk Road, Varanasi, UP - 221106',
      phone: '+91 94152 77889',
      altPhone: '+91 99351 22331',
      stockGrades: ['Fe 550D', 'Fe 550D CRS', 'Stirrups'],
      deliveryCapacity: 'Same-day Eastern UP coverage',
    },
    {
      id: 'd4',
      name: 'Sangam Building Materials & Rebar',
      contactPerson: 'Amitabh Jaiswal',
      city: 'Prayagraj',
      district: 'Prayagraj',
      address: 'Naini Industrial Area, Near Power House, Prayagraj, UP - 211008',
      phone: '+91 94153 11223',
      altPhone: '+91 98391 99887',
      stockGrades: ['Fe 550D', 'Fe 600'],
      deliveryCapacity: 'Immediate delivery across Prayagraj',
    },
    {
      id: 'd5',
      name: 'Gorakhnath Iron & Hardwares',
      contactPerson: 'Pradeep Pandey',
      city: 'Gorakhpur',
      district: 'Gorakhpur',
      address: 'GIDA Sector 15, Gorakhpur, UP - 273209',
      phone: '+91 94511 66778',
      altPhone: '+91 98382 33445',
      stockGrades: ['Fe 550D', 'Stirrups', 'Wire Rods'],
      deliveryCapacity: 'Express transit for Gorakhpur & Basti',
      isSuperStockist: true,
    },
    {
      id: 'd6',
      name: 'Taj City Steel Traders',
      contactPerson: 'Sunil Agrawal',
      city: 'Agra',
      district: 'Agra',
      address: 'Foundry Nagar, Belanganj Extension, Agra, UP - 282006',
      phone: '+91 98370 55443',
      altPhone: '+91 94122 88776',
      stockGrades: ['Fe 550D', 'Fe 550D CRS', 'Fe 600'],
      deliveryCapacity: 'Same-day Agra & Mathura supply',
    },
    {
      id: 'd7',
      name: 'Meerut Metro Steel Syndicate',
      contactPerson: 'Harsh Vardhan Sharma',
      city: 'Meerut',
      district: 'Meerut',
      address: 'Delhi Road, Partapur Industrial Area, Meerut, UP - 250103',
      phone: '+91 98371 11224',
      altPhone: '+91 94121 99881',
      stockGrades: ['Fe 550D', 'Fe 600', 'Stirrups'],
      deliveryCapacity: 'Rapid transit across Western UP',
    },
    {
      id: 'd8',
      name: 'NCR Infra Steel & Heavy Rebars',
      contactPerson: 'Sanjay Malik',
      city: 'Ghaziabad / Noida',
      district: 'Ghaziabad',
      address: 'Loni Road Industrial Area, Site 2, Ghaziabad, UP - 201007',
      phone: '+91 98100 44556',
      altPhone: '+91 98111 88990',
      stockGrades: ['Fe 550D', 'Fe 600', 'Fe 550D CRS'],
      deliveryCapacity: 'Dedicated fleet for NCR high-rise towers',
      isSuperStockist: true,
    },
    {
      id: 'd9',
      name: 'Rohilkhand Iron & Steel Agency',
      contactPerson: 'Dinesh Rastogi',
      city: 'Bareilly',
      district: 'Bareilly',
      address: 'CB Ganj Industrial Area, Bareilly, UP - 243502',
      phone: '+91 94120 77665',
      altPhone: '+91 98372 44332',
      stockGrades: ['Fe 550D', 'Stirrups'],
      deliveryCapacity: 'Full stock in 8mm to 25mm dia',
    },
    {
      id: 'd10',
      name: 'Ayodhya Dham Construction Steels',
      contactPerson: 'Rameshwar Pathak',
      city: 'Ayodhya',
      district: 'Ayodhya',
      address: 'Naya Ghat Bypass Road, Ayodhya, UP - 224123',
      phone: '+91 94520 88991',
      altPhone: '+91 98394 55667',
      stockGrades: ['Fe 550D', 'Fe 550D CRS', 'Stirrups'],
      deliveryCapacity: 'Priority dispatch for new projects',
      isSuperStockist: true,
    },
  ];

  const cities = ['All', 'Kanpur', 'Lucknow', 'Varanasi', 'Prayagraj', 'Gorakhpur', 'Agra', 'Meerut', 'Ghaziabad / Noida', 'Bareilly', 'Ayodhya'];

  const filteredDealers = dealersList.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.contactPerson.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = selectedCityFilter === 'All' || d.city.includes(selectedCityFilter);
    return matchesSearch && matchesCity;
  });

  const handlePartnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partnerName || !partnerPhone) return;
    setDealershipSubmitted(true);
  };

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Authorized Dealer Network</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <MapPin className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                500+ AUTHORIZED STOCKISTS &amp; REGIONAL DEPOTS
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              AUTHORIZED <span className="text-[#D9A700]">DEALER NETWORK</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Find authentic, 100% rust-free Balwant TMT steel near your construction site. Guaranteed primary steel, verified weighing scales, and immediate delivery across Uttar Pradesh and Northern India.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Search & City Filter Bar */}
      <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-white border-2 border-amber-300 p-4 sm:p-6 rounded-xs shadow-md mb-10 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-1/2">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Dealer Name, City, Pincode or Area..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-300 pl-10 pr-4 py-2.5 rounded-xs text-xs sm:text-sm font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            <span className="text-xs font-mono-tech text-zinc-500 font-bold uppercase whitespace-nowrap">
              City:
            </span>
            <select
              value={selectedCityFilter}
              onChange={(e) => setSelectedCityFilter(e.target.value)}
              className="bg-zinc-50 border border-zinc-300 py-2.5 px-3 rounded-xs text-xs sm:text-sm font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 font-bold cursor-pointer"
            >
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Dealer Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredDealers.map((d) => (
            <div
              key={d.id}
              className="bg-white border border-amber-200 p-6 rounded-xs shadow-xs hover:shadow-md hover:border-amber-400 transition-all flex flex-col justify-between text-left"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono-tech bg-amber-100 text-amber-900 px-2 py-0.5 rounded-xs font-bold uppercase">
                    {d.city}
                  </span>
                  {d.isSuperStockist && (
                    <span className="text-[10px] font-mono-tech bg-black text-[#FFD700] px-2 py-0.5 rounded-xs font-black uppercase">
                      SUPER STOCKIST
                    </span>
                  )}
                </div>

                <h3 className="font-display font-black text-lg text-zinc-900 uppercase leading-snug mb-1">
                  {d.name}
                </h3>
                <p className="text-xs font-mono-tech text-amber-800 font-semibold mb-3">
                  Prop: {d.contactPerson}
                </p>

                <div className="flex items-start gap-2 text-xs text-zinc-600 mb-4">
                  <MapPin className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
                  <span>{d.address}</span>
                </div>

                <div className="space-y-1.5 mb-4 bg-[#FFFDF0] p-3 rounded-xs border border-amber-200">
                  <div className="flex items-center justify-between text-xs font-mono-tech">
                    <span className="text-zinc-500">Stock Availability:</span>
                    <span className="text-zinc-900 font-bold">{d.stockGrades.join(', ')}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs font-mono-tech">
                    <span className="text-zinc-500">Dispatch:</span>
                    <span className="text-emerald-700 font-bold">{d.deliveryCapacity}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-zinc-100 flex items-center gap-2">
                <a
                  href={`tel:${d.phone.replace(/[^0-9+]/g, '')}`}
                  className="flex-1 bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase py-2 px-3 rounded-xs text-center flex items-center justify-center gap-1.5 border border-amber-400 cursor-pointer shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Dealer</span>
                </a>
                <button
                  onClick={() => onOpenEnquiry(`Dealer Order: ${d.name} (${d.city})`)}
                  className="bg-white hover:bg-zinc-100 text-zinc-800 border border-zinc-300 font-display font-bold text-xs uppercase py-2 px-3 rounded-xs cursor-pointer shadow-xs"
                >
                  Book Stock
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* 3. Dealership Registration Form */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4 text-left">
              <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3 py-1 rounded-xs">
                <Building2 className="w-4 h-4 text-amber-700" />
                <span className="font-mono-tech text-xs font-bold text-amber-900 uppercase">
                  Distributor &amp; Retail Partnerships
                </span>
              </div>

              <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
                BECOME AN AUTHORIZED BALWANT DEALER
              </h3>

              <p className="text-zinc-700 text-sm font-medium leading-relaxed">
                Join Northern India's fastest-growing primary steel distribution network. Benefit from direct factory wholesale pricing, high customer demand, priority logistics, and 360° marketing support.
              </p>

              <div className="space-y-2 pt-2">
                <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-800 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Tier-1 Direct Mill Billing &amp; Protected Territorial Territory</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-800 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Free Dealer Branding Signboards, Banners &amp; Marketing Kit</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-800 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>24-Hour Direct Trailer Dispatch from Kanpur Mill</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white border border-amber-300 p-6 sm:p-8 rounded-xs shadow-md">
              {dealershipSubmitted ? (
                <div className="text-center py-8 space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="font-display font-black text-xl text-zinc-900 uppercase">
                    Application Received!
                  </h4>
                  <p className="text-xs text-zinc-600 max-w-sm mx-auto">
                    Our Regional Sales Head for {partnerCity || 'your area'} will contact you on {partnerPhone} within 4 working hours with full dealership terms.
                  </p>
                </div>
              ) : (
                <form onSubmit={handlePartnerSubmit} className="space-y-4 text-left">
                  <h4 className="font-display font-black text-lg text-zinc-900 uppercase mb-3">
                    Dealership Enquiry Form
                  </h4>

                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Business / Firm Name &amp; Contact Person *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sharma Building Materials (Rohan Sharma)"
                      value={partnerName}
                      onChange={(e) => setPartnerName(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                        Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 98765 43210"
                        value={partnerPhone}
                        onChange={(e) => setPartnerPhone(e.target.value)}
                        className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                        Target City / District *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Gorakhpur, UP"
                        value={partnerCity}
                        onChange={(e) => setPartnerCity(e.target.value)}
                        className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono-tech font-bold text-zinc-700 uppercase mb-1">
                      Current Building Material / Hardware Experience
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Existing cement/steel retailer with 5,000 sq ft godown"
                      value={partnerExperience}
                      onChange={(e) => setPartnerExperience(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-300 px-3.5 py-2.5 rounded-xs text-xs font-mono-tech text-zinc-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider py-3.5 rounded-xs shadow-md border border-amber-400 cursor-pointer flex items-center justify-center gap-2 transition-all"
                  >
                    <span>Submit Dealership Proposal</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
