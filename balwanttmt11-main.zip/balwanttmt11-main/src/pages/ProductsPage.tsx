import React, { useState } from 'react';
import {
  ShieldCheck,
  Flame,
  Award,
  CheckCircle2,
  Download,
  ArrowUpRight,
  Calculator,
  Layers,
  Sparkles,
  Zap,
  Building2,
  Home,
  Check,
  FileText,
  PhoneCall,
  ChevronRight,
  Info
} from 'lucide-react';
import { BALWANT_PRODUCTS, BAR_DIAMETERS, ProductGrade, BarDiameter } from '../data/tmtData';
import { useLanguage } from '../context/LanguageContext';
import pristineRebarImg from '../assets/images/tmt_rustfree_bars_final.jpg';
import cleanBundlesImg from '../assets/images/tmt_rustfree_bundles_final.jpg';
import cleanHeroImg from '../assets/images/tmt_rustfree_hero_final.jpg';

interface ProductsPageProps {
  onOpenEnquiry: (grade?: string) => void;
  onOpenDealer: () => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({ onOpenEnquiry, onOpenDealer }) => {
  const { language } = useLanguage();
  const [selectedGradeId, setSelectedGradeId] = useState<string>('550d');
  const [selectedDiameterMm, setSelectedDiameterMm] = useState<number>(12);

  // Calculator State
  const [calcArea, setCalcArea] = useState<number>(1200);
  const [calcFloors, setCalcFloors] = useState<number>(2);
  const [calcStructureType, setCalcStructureType] = useState<'residential' | 'commercial' | 'heavy'>('residential');

  const selectedProduct = BALWANT_PRODUCTS.find((p) => p.id === selectedGradeId) || BALWANT_PRODUCTS[0];
  const selectedDia = BAR_DIAMETERS.find((d) => d.diameterMm === selectedDiameterMm) || BAR_DIAMETERS[2];

  // Estimation math (approx 3.5 - 4.5 kg per sq ft of builtup area per floor)
  const rateFactor = calcStructureType === 'residential' ? 4.0 : calcStructureType === 'commercial' ? 5.2 : 6.5;
  const totalEstimatedKg = Math.round(calcArea * calcFloors * rateFactor);
  const totalEstimatedTonnes = (totalEstimatedKg / 1000).toFixed(2);

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Page Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto relative z-10">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">Products &amp; Technical Specifications</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                BIS IS: 1786 : 2008 &amp; ISO 9001:2015 CERTIFIED
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              BALWANT TMT <span className="text-[#D9A700]">PRODUCT PORTFOLIO</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Manufactured from 100% prime virgin iron ore billets utilizing German Thermex® Quenching and Self-Tempering (QST) automation. Engineered with superior ductility, corrosion resistance, and high-bonding ribs for maximum structural longevity.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Grade Selector & Product Showcase */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Grade Tabs */}
        <div className="flex flex-wrap gap-2.5 mb-10 border-b border-amber-200 pb-4">
          {BALWANT_PRODUCTS.map((prod) => (
            <button
              key={prod.id}
              onClick={() => setSelectedGradeId(prod.id)}
              className={`px-5 py-3 rounded-xs font-display font-black text-sm uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border ${
                selectedGradeId === prod.id
                  ? 'bg-[#FFD700] text-black border-amber-400 shadow-sm scale-105'
                  : 'bg-white text-zinc-700 border-zinc-200 hover:border-amber-300 hover:bg-amber-50/50'
              }`}
            >
              <span>{prod.grade}</span>
              {prod.isPrimary && (
                <span className="text-[10px] bg-black text-[#FFD700] px-1.5 py-0.5 rounded-xs font-mono-tech font-bold">
                  FLAGSHIP
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Selected Product Deep Dive Card */}
        <div className="bg-white border-2 border-amber-300/80 rounded-xs shadow-md p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          {/* Left Column: Grade Specs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div>
              <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1 rounded-xs mb-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                <span className="font-mono-tech text-xs font-bold text-amber-900 uppercase">
                  {selectedProduct.tag}
                </span>
              </div>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-zinc-900 uppercase tracking-tight">
                {selectedProduct.name}
              </h2>
              <p className="text-sm font-semibold text-[#D9A700] mt-1 font-mono-tech uppercase">
                {selectedProduct.subheading}
              </p>
            </div>

            <p className="text-zinc-700 text-sm sm:text-base leading-relaxed">
              {selectedProduct.description}
            </p>

            {/* Technical Parameters Matrix */}
            <div className="grid grid-cols-3 gap-3 sm:gap-4 bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <div>
                <span className="text-[10px] sm:text-xs font-mono-tech text-zinc-500 uppercase font-semibold block">
                  Yield Strength (YS)
                </span>
                <span className="font-display font-black text-base sm:text-lg text-zinc-900 block mt-0.5">
                  {selectedProduct.yieldStrength}
                </span>
              </div>
              <div className="border-l border-amber-200 pl-3">
                <span className="text-[10px] sm:text-xs font-mono-tech text-zinc-500 uppercase font-semibold block">
                  Tensile Strength (UTS)
                </span>
                <span className="font-display font-black text-base sm:text-lg text-zinc-900 block mt-0.5">
                  {selectedProduct.tensileStrength}
                </span>
              </div>
              <div className="border-l border-amber-200 pl-3">
                <span className="text-[10px] sm:text-xs font-mono-tech text-zinc-500 uppercase font-semibold block">
                  Elongation %
                </span>
                <span className="font-display font-black text-base sm:text-lg text-emerald-700 block mt-0.5">
                  {selectedProduct.elongation}
                </span>
              </div>
            </div>

            {/* Key Features List */}
            <div>
              <h3 className="font-display font-black text-sm uppercase tracking-wider text-zinc-900 mb-3">
                Key Engineering Advantages
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {selectedProduct.keyFeatures.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-zinc-800 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onOpenEnquiry(selectedProduct.grade)}
                className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs shadow-sm flex items-center gap-2 border border-amber-400 cursor-pointer transition-all hover:scale-105 active:scale-95"
              >
                <span>Request {selectedProduct.grade} Quote</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenDealer}
                className="bg-white hover:bg-zinc-100 text-zinc-900 border border-zinc-300 hover:border-amber-400 font-display font-bold text-xs sm:text-sm uppercase tracking-wider px-5 py-3.5 rounded-xs transition-all flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <span>Find Dealer Stock</span>
              </button>
            </div>
          </div>

          {/* Right Column: Pristine Rust-Free Product Imagery */}
          <div className="lg:col-span-5 relative">
            <div className="relative bg-zinc-900 rounded-xs overflow-hidden border border-amber-300 shadow-xl group">
              <img
                src={pristineRebarImg}
                alt={`${selectedProduct.name} Rust-Free Precision Steel Rebar`}
                className="w-full h-80 sm:h-96 object-cover object-center filter brightness-100 contrast-[1.05] saturate-[1.1] transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

              {/* Branding Pill on Product */}
              <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md border border-amber-300 px-3.5 py-1.5 rounded-xs shadow-md">
                <span className="font-mono-tech text-xs font-black text-amber-900 uppercase">
                  100% RUST-FREE • PRIMARY VIRGIN BILLET
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md border border-amber-200 p-3 rounded-xs shadow-md">
                <div className="flex items-center justify-between text-xs font-mono-tech">
                  <span className="text-zinc-600 font-semibold">Corrosion Resistance</span>
                  <span className="text-emerald-700 font-black">ASTM B117 Tested</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono-tech mt-1">
                  <span className="text-zinc-600 font-semibold">Re-Bend Test</span>
                  <span className="text-zinc-900 font-black">180° Zero Micro-Crack</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Bar Diameter Specification Chart (8mm to 32mm) */}
        <div className="mb-16">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-amber-200 gap-4">
            <div>
              <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
                Standard Sectional Properties
              </span>
              <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
                DIAMETER &amp; WEIGHT SPECIFICATIONS (IS: 1786)
              </h3>
            </div>
            <p className="text-xs font-mono-tech text-zinc-600 max-w-md">
              All Balwant TMT bars adhere to strict rolling tolerance limits under BIS IS:1786:2008, preventing overweight penalties for builders.
            </p>
          </div>

          {/* Interactive Diameter Buttons */}
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-6">
            {BAR_DIAMETERS.map((dia) => (
              <button
                key={dia.diameterMm}
                onClick={() => setSelectedDiameterMm(dia.diameterMm)}
                className={`p-3 rounded-xs text-center border transition-all cursor-pointer ${
                  selectedDiameterMm === dia.diameterMm
                    ? 'bg-[#FFD700] border-amber-400 shadow-sm font-black text-black scale-105'
                    : 'bg-white border-zinc-200 text-zinc-700 hover:border-amber-300'
                }`}
              >
                <span className="font-display text-lg block">{dia.diameterMm} mm</span>
                <span className="text-[10px] font-mono-tech text-zinc-600 block mt-0.5">
                  {dia.weightPerMeterKg} kg/m
                </span>
              </button>
            ))}
          </div>

          {/* Detailed Diameter Table */}
          <div className="bg-white border border-amber-200 rounded-xs shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm font-mono-tech">
              <thead className="bg-amber-50 text-zinc-900 border-b border-amber-200 font-bold uppercase">
                <tr>
                  <th className="py-3 px-4">Bar Diameter (mm)</th>
                  <th className="py-3 px-4">Std. Weight (kg/m)</th>
                  <th className="py-3 px-4">IS:1786 Tolerance</th>
                  <th className="py-3 px-4">Pieces / Bundle</th>
                  <th className="py-3 px-4">Recommended Application</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 text-zinc-800">
                {BAR_DIAMETERS.map((dia) => (
                  <tr
                    key={dia.diameterMm}
                    className={`transition-colors ${
                      dia.diameterMm === selectedDiameterMm
                        ? 'bg-amber-100/70 font-bold text-zinc-900'
                        : 'hover:bg-amber-50/50'
                    }`}
                  >
                    <td className="py-3 px-4 font-display font-black text-base text-zinc-900">
                      {dia.diameterMm} mm
                    </td>
                    <td className="py-3 px-4 font-bold text-amber-900">{dia.weightPerMeterKg} kg/m</td>
                    <td className="py-3 px-4 text-emerald-700 font-semibold">{dia.tolerance}</td>
                    <td className="py-3 px-4">{dia.piecesPerBundle} pcs</td>
                    <td className="py-3 px-4 text-zinc-700">{dia.primaryUse}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 4. Live Steel Tonnage & House Requirement Calculator */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3 py-1 rounded-xs">
                <Calculator className="w-4 h-4 text-amber-700" />
                <span className="font-mono-tech text-xs font-bold text-amber-900 uppercase">
                  Instant Structural Estimator
                </span>
              </div>
              <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
                CALCULATE YOUR TMT STEEL REQUIREMENT
              </h3>
              <p className="text-zinc-700 text-sm font-medium">
                Estimate the approximate quantity of Balwant TMT Fe 550D required for your residential home, commercial complex, or industrial shed.
              </p>

              <div className="space-y-4 pt-2">
                {/* Built-up area slider */}
                <div>
                  <div className="flex justify-between text-xs font-mono-tech font-bold text-zinc-800 mb-1">
                    <span>Plot / Built-up Area:</span>
                    <span className="text-amber-800">{calcArea} Sq. Ft.</span>
                  </div>
                  <input
                    type="range"
                    min={400}
                    max={10000}
                    step={100}
                    value={calcArea}
                    onChange={(e) => setCalcArea(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Number of Floors */}
                <div>
                  <div className="flex justify-between text-xs font-mono-tech font-bold text-zinc-800 mb-1">
                    <span>Number of Floors (G + N):</span>
                    <span className="text-amber-800">{calcFloors} Storeys</span>
                  </div>
                  <input
                    type="range"
                    min={1}
                    max={10}
                    step={1}
                    value={calcFloors}
                    onChange={(e) => setCalcFloors(Number(e.target.value))}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Structure Type */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setCalcStructureType('residential')}
                    className={`flex-1 py-2 px-3 rounded-xs text-xs font-mono-tech font-bold uppercase transition-all cursor-pointer border ${
                      calcStructureType === 'residential'
                        ? 'bg-[#FFD700] text-black border-amber-400 shadow-xs'
                        : 'bg-white text-zinc-700 border-zinc-300'
                    }`}
                  >
                    Residential House
                  </button>
                  <button
                    onClick={() => setCalcStructureType('commercial')}
                    className={`flex-1 py-2 px-3 rounded-xs text-xs font-mono-tech font-bold uppercase transition-all cursor-pointer border ${
                      calcStructureType === 'commercial'
                        ? 'bg-[#FFD700] text-black border-amber-400 shadow-xs'
                        : 'bg-white text-zinc-700 border-zinc-300'
                    }`}
                  >
                    Commercial Complex
                  </button>
                  <button
                    onClick={() => setCalcStructureType('heavy')}
                    className={`flex-1 py-2 px-3 rounded-xs text-xs font-mono-tech font-bold uppercase transition-all cursor-pointer border ${
                      calcStructureType === 'heavy'
                        ? 'bg-[#FFD700] text-black border-amber-400 shadow-xs'
                        : 'bg-white text-zinc-700 border-zinc-300'
                    }`}
                  >
                    Heavy Industrial
                  </button>
                </div>
              </div>
            </div>

            {/* Right Estimation Result Box */}
            <div className="lg:col-span-6 bg-white border border-amber-300 p-6 sm:p-8 rounded-xs shadow-md text-center">
              <span className="font-mono-tech text-xs text-zinc-500 uppercase font-bold block mb-1">
                Estimated Total Steel Volume
              </span>
              <div className="font-display font-black text-4xl sm:text-5xl text-zinc-900 mb-2">
                {totalEstimatedTonnes}{' '}
                <span className="text-xl text-[#D9A700] font-mono-tech font-bold">Metric Tonnes</span>
              </div>
              <span className="text-xs font-mono-tech text-zinc-600 block mb-6">
                (≈ {totalEstimatedKg.toLocaleString()} Kilograms across 8mm to 25mm dia)
              </span>

              <div className="grid grid-cols-3 gap-2 bg-[#FFFDF0] p-3 rounded-xs border border-amber-200 text-left text-xs font-mono-tech mb-6">
                <div>
                  <span className="text-zinc-500 block text-[10px]">Slab &amp; Rings (8/10mm)</span>
                  <span className="font-bold text-zinc-900">{(Number(totalEstimatedTonnes) * 0.45).toFixed(1)} MT</span>
                </div>
                <div className="border-l border-amber-200 pl-2">
                  <span className="text-zinc-500 block text-[10px]">Beams (12/16mm)</span>
                  <span className="font-bold text-zinc-900">{(Number(totalEstimatedTonnes) * 0.35).toFixed(1)} MT</span>
                </div>
                <div className="border-l border-amber-200 pl-2">
                  <span className="text-zinc-500 block text-[10px]">Columns (20/25mm)</span>
                  <span className="font-bold text-zinc-900">{(Number(totalEstimatedTonnes) * 0.20).toFixed(1)} MT</span>
                </div>
              </div>

              <button
                onClick={() => onOpenEnquiry(`Fe 550D (${totalEstimatedTonnes} MT estimate)`)}
                className="w-full bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-sm uppercase tracking-wider py-3.5 rounded-xs shadow-md border border-amber-400 cursor-pointer flex items-center justify-center gap-2 transition-all hover:scale-105"
              >
                <span>Get Exact Factory Price for {totalEstimatedTonnes} MT</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
