import React from 'react';
import {
  Calculator,
  ChevronRight,
  ShieldCheck,
  Building2,
  FileDown,
  Info,
  Scale,
  Sparkles,
  ArrowUpRight,
  Layers,
  CheckCircle2,
  BookOpen
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { TmtCalculator } from '../components/TmtCalculator';
import { BAR_DIAMETERS } from '../data/tmtData';

interface CalculatorPageProps {
  onOpenEnquiry: (details?: string) => void;
  onOpenDealer: () => void;
}

export const CalculatorPage: React.FC<CalculatorPageProps> = ({
  onOpenEnquiry,
  onOpenDealer,
}) => {
  const { language } = useLanguage();

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Top Hero & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden text-left">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">TMT Steel Estimation Tool</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <Calculator className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                CIVIL ENGINEERING QUANTITY CALCULATOR
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              TMT STEEL <span className="text-[#D9A700]">ESTIMATE CALCULATOR</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              {language === 'hi'
                ? 'अपने भवन निर्माण के लिए कुल सरिया की मात्रा (टन), व्यास अनुसार बंडल संख्या एवं बजट का तुरंत और सटीक अनुमान लगाएं।'
                : 'Accurately forecast structural reinforcement steel tonnage, bar diameter allocations, bundle requirements, and budget for your residential or commercial project.'}
            </p>
          </div>
        </div>
      </section>

      {/* 2. Interactive Calculator Section */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <TmtCalculator
          onOpenEnquiry={onOpenEnquiry}
          onOpenDealer={onOpenDealer}
        />

        {/* 3. Thumb Rules for Steel Estimation */}
        <div className="mt-12 bg-white border-2 border-amber-300 rounded-xs p-6 sm:p-10 shadow-md text-left">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-amber-200">
            <BookOpen className="w-5 h-5 text-amber-700" />
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              {language === 'hi' ? 'भवन निर्माण में सरिया का सामान्य थम्ब रूल' : 'Civil Engineering Thumb Rules for Steel Estimation'}
            </h3>
          </div>

          <p className="text-zinc-600 text-sm mb-6 leading-relaxed">
            {language === 'hi'
              ? 'भारतीय सिविल इंजीनियरिंग मानकों (IS 456:2000) के अनुसार विभिन्न संरचनात्मक घटकों में कंक्रीट आयतन के सापेक्ष सरिया का औसत अनुपात निम्नलिखित होता है:'
              : 'As per Indian Standard IS 456:2000 and SP 16 design handbooks, the standard steel density percentage relative to concrete volume across key structural members:'}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <div className="font-mono-tech text-xs font-black text-amber-900 uppercase mb-1">
                1. FOOTINGS &amp; FOUNDATIONS
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 mb-1">
                0.5% - 0.8%
              </div>
              <p className="text-xs text-zinc-600">
                Of total concrete volume. Primary mesh: 12mm &amp; 16mm bars spaced at 150mm c/c.
              </p>
            </div>

            <div className="bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <div className="font-mono-tech text-xs font-black text-amber-900 uppercase mb-1">
                2. COLUMNS &amp; PILLARS
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 mb-1">
                1.5% - 3.5%
              </div>
              <p className="text-xs text-zinc-600">
                Main vertical bars: 12mm, 16mm &amp; 20mm with 8mm stirrup rings at 100-150mm spacing.
              </p>
            </div>

            <div className="bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <div className="font-mono-tech text-xs font-black text-amber-900 uppercase mb-1">
                3. BEAMS &amp; LINTELS
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 mb-1">
                1.0% - 2.0%
              </div>
              <p className="text-xs text-zinc-600">
                Top &amp; bottom longitudinal bars: 12mm &amp; 16mm, shear stirrups: 8mm.
              </p>
            </div>

            <div className="bg-[#FFFDF0] p-4 rounded-xs border border-amber-200">
              <div className="font-mono-tech text-xs font-black text-amber-900 uppercase mb-1">
                4. ROOF SLABS
              </div>
              <div className="font-display font-black text-2xl text-zinc-900 mb-1">
                0.7% - 1.0%
              </div>
              <p className="text-xs text-zinc-600">
                Main reinforcement: 10mm or 8mm spaced at 125-150mm with alternate crank/bent-up bars.
              </p>
            </div>
          </div>
        </div>

        {/* 4. IS: 1786 Section Weight Reference Chart */}
        <div className="mt-8 bg-white border-2 border-amber-300 rounded-xs p-6 sm:p-10 shadow-md text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-6 border-b border-amber-200 gap-4">
            <div>
              <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
                IS: 1786 : 2008 SECTION WEIGHT &amp; BUNDLE CHART
              </h3>
              <p className="text-xs text-zinc-500 font-mono-tech">
                Standard Length per Bar: 12.0 Meters (39.37 Feet)
              </p>
            </div>
            <button
              onClick={() => onOpenEnquiry('Standard Weight Chart Download')}
              className="inline-flex items-center gap-1.5 text-xs font-mono-tech bg-amber-100 text-amber-900 px-3 py-1.5 rounded-xs font-bold border border-amber-300 hover:bg-amber-200 cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Download Weight Chart PDF</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono-tech text-xs sm:text-sm">
              <thead className="bg-amber-50 text-zinc-900 uppercase font-bold text-xs border-b border-amber-200">
                <tr>
                  <th className="py-3 px-4">Bar Diameter</th>
                  <th className="py-3 px-4">Weight / Meter (kg)</th>
                  <th className="py-3 px-4">Weight / 12m Bar (kg)</th>
                  <th className="py-3 px-4">Bars / Bundle</th>
                  <th className="py-3 px-4">Weight / Bundle (kg)</th>
                  <th className="py-3 px-4">IS Tolerance</th>
                  <th className="py-3 px-4">Structural Placement</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 text-zinc-800">
                {BAR_DIAMETERS.map((bar) => {
                  const weightPer12m = (bar.weightPerMeterKg * 12).toFixed(2);
                  const weightPerBundle = (Number(weightPer12m) * bar.piecesPerBundle).toFixed(2);
                  return (
                    <tr key={bar.diameterMm} className="hover:bg-amber-50/50 transition-colors">
                      <td className="py-3 px-4 font-black text-zinc-900 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#D9A700]" />
                        <span>{bar.diameterMm} mm</span>
                      </td>
                      <td className="py-3 px-4 font-bold text-amber-900">{bar.weightPerMeterKg.toFixed(3)} kg</td>
                      <td className="py-3 px-4">{weightPer12m} kg</td>
                      <td className="py-3 px-4 font-bold">{bar.piecesPerBundle} pcs</td>
                      <td className="py-3 px-4 font-black text-zinc-900">{weightPerBundle} kg</td>
                      <td className="py-3 px-4 text-zinc-600">{bar.tolerance}</td>
                      <td className="py-3 px-4 text-zinc-600 text-xs">{bar.primaryUse}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 5. Consultation Action Banner */}
        <div className="mt-8 bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 text-white p-6 sm:p-10 rounded-xs border-2 border-amber-400 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 text-left">
          <div className="space-y-2">
            <span className="text-xs font-mono-tech text-[#FFD700] uppercase font-bold tracking-wider">
              HAVE DETAILED BLUEPRINTS OR STRUCTURAL DRAWINGS?
            </span>
            <h4 className="font-display font-black text-2xl sm:text-3xl uppercase text-white">
              GET A CUSTOM BAR BENDING SCHEDULE (BBS) BY METALLURGISTS
            </h4>
            <p className="text-zinc-300 text-xs sm:text-sm max-w-2xl font-sans">
              Send your foundation and column structural blueprints to our engineering desk for an itemized Bar Bending Schedule and bulk factory dispatch pricing.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0 w-full md:w-auto">
            <button
              onClick={() => onOpenEnquiry('Custom BBS Schedule Review Request')}
              className="w-full md:w-auto bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs border border-amber-300 shadow-lg cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Submit Drawings for BBS</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
