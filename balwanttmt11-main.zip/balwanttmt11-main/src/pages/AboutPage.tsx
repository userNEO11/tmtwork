import React from 'react';
import {
  ShieldCheck,
  Flame,
  Award,
  CheckCircle2,
  Building2,
  Layers,
  Sparkles,
  ChevronRight,
  ArrowUpRight,
  HeartHandshake,
  Quote
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import pristineRebarImg from '../assets/images/tmt_rustfree_bars_final.jpg';
import pristineBundlesImg from '../assets/images/tmt_rustfree_bundles_final.jpg';
import millImg from '../assets/images/tmt_mill_sparks_bright_1787135359045.jpg';

interface AboutPageProps {
  onOpenEnquiry: () => void;
  onOpenDealer: () => void;
  onNavigate?: (page: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onOpenEnquiry, onOpenDealer, onNavigate }) => {
  const { language } = useLanguage();

  return (
    <div className="w-full bg-[#FFFDF0] text-zinc-900 min-h-screen">
      {/* 1. Header & Breadcrumbs */}
      <section className="bg-gradient-to-b from-amber-50 to-[#FFFDF0] border-b border-amber-200/80 pt-12 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FFD700]/15 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono-tech text-zinc-500 mb-4 uppercase">
            <span className="hover:text-black cursor-pointer">Home</span>
            <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
            <span className="text-amber-800 font-bold">About Balwant TMT</span>
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white border border-amber-300 px-3.5 py-1 rounded-xs mb-3 shadow-xs">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span className="font-mono-tech text-xs font-black text-amber-900 uppercase tracking-wider">
                50+ YEARS OF METALLURGICAL EXCELLENCE
              </span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-5xl md:text-6xl text-zinc-900 uppercase tracking-tight leading-none mb-4">
              PIONEERING STEEL <span className="text-[#D9A700]">FOR GENERATIONS</span>
            </h1>

            <p className="text-zinc-700 text-base sm:text-lg leading-relaxed font-medium">
              Founded on the unshakeable promise that <em>"सरिया नहीं, फौलाद है ये"</em>, Balwant TMT is one of Northern India's premier integrated steel manufacturers, dedicated to 100% prime virgin steelmaking.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Core Pillars & Story */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          <div className="lg:col-span-7 space-y-6 text-left">
            <div>
              <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
                Our Heritage &amp; Mission
              </span>
              <h2 className="font-display font-black text-3xl sm:text-4xl text-zinc-900 uppercase tracking-tight">
                STEEL CRAFTED WITH ZERO COMPROMISE
              </h2>
            </div>

            <p className="text-zinc-700 text-sm sm:text-base leading-relaxed">
              In a marketplace flooded with re-rolled scrap iron and inconsistent ingots, Balwant TMT took the resolute stand to produce steel exclusively through 100% primary virgin billets in continuous casting machines.
            </p>

            <p className="text-zinc-700 text-sm sm:text-base leading-relaxed">
              Equipped with German Hennigsdorfer Thermex® quenching automation and state-of-the-art tandem hot rolling stands, our automated manufacturing facilities in Uttar Pradesh ensure every meter of rebar delivers uncompromising yield strength, superior elongation ductility, and fire-safe durability.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-white border border-amber-200 p-4 rounded-xs shadow-xs">
                <span className="font-display font-black text-3xl text-zinc-900 block">50+</span>
                <span className="text-[11px] font-mono-tech text-zinc-600 uppercase font-bold mt-1 block">
                  Years of Leadership
                </span>
              </div>
              <div className="bg-white border border-amber-200 p-4 rounded-xs shadow-xs">
                <span className="font-display font-black text-3xl text-amber-800 block">100%</span>
                <span className="text-[11px] font-mono-tech text-zinc-600 uppercase font-bold mt-1 block">
                  Virgin Primary Billet
                </span>
              </div>
              <div className="bg-white border border-amber-200 p-4 rounded-xs shadow-xs">
                <span className="font-display font-black text-2xl sm:text-3xl text-emerald-700 block">500+ / 50K+</span>
                <span className="text-[11px] font-mono-tech text-zinc-600 uppercase font-bold mt-1 block">
                  Distributors &amp; Dealers
                </span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative bg-zinc-900 rounded-xs overflow-hidden border border-amber-300 shadow-xl group">
              <img
                src={millImg}
                alt="Balwant Steel Automated Rolling Mill"
                className="w-full h-80 sm:h-96 object-cover object-center filter brightness-100 contrast-[1.05] saturate-[1.1] transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md border border-amber-200 p-3 rounded-xs shadow-md text-left">
                <span className="font-mono-tech text-xs font-black text-zinc-900 uppercase block">
                  INTEGRATED STEEL MANUFACTURING FACILITY
                </span>
                <span className="text-[11px] font-mono-tech text-zinc-600 block mt-0.5">
                  Uttar Pradesh, India • NABL Accredited Plant Lab
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Link to Chairman's Message & Leadership */}
        {onNavigate && (
          <div className="bg-white border-2 border-amber-300 p-6 sm:p-8 rounded-xs shadow-md mb-12 flex flex-col md:flex-row items-center justify-between gap-6 text-left">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 text-xs font-mono-tech font-bold text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded-xs">
                <Quote className="w-3.5 h-3.5 text-amber-700" />
                FOUNDER'S PERSPECTIVE
              </div>
              <h3 className="font-display font-black text-2xl text-zinc-900 uppercase">
                FROM THE DESK OF P.N SINGH
              </h3>
              <p className="text-zinc-600 text-sm max-w-2xl">
                Read our Chairman's complete personal address on 50 years of integrity, zero-ingot policy, and seismic safety for future generations.
              </p>
            </div>
            <button
              onClick={() => onNavigate('chairman')}
              className="w-full md:w-auto bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs uppercase tracking-wider px-6 py-3.5 rounded-xs border border-amber-400 cursor-pointer shadow-md flex items-center justify-center gap-2 flex-shrink-0"
            >
              <span>Visit Chairman's Page</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* 4. Sustainable Green Steelmaking */}
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border-2 border-amber-300 p-6 sm:p-8 lg:p-10 rounded-xs shadow-md">
          <div className="max-w-3xl mb-6 text-left">
            <span className="text-xs font-mono-tech text-amber-800 font-bold uppercase tracking-wider block mb-1">
              Sustainability &amp; Green Production
            </span>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-zinc-900 uppercase">
              COMMITTED TO RESPONSIBLE STEELMAKING
            </h3>
            <p className="text-zinc-700 text-sm font-medium mt-2">
              Our advanced induction melting process uses clean electrical energy, advanced bag-filter dedusting systems for zero fugitive atmospheric emissions, and 100% closed-loop cooling water recycling.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={onOpenEnquiry}
              className="bg-[#FFD700] hover:bg-[#F5C700] text-black font-display font-black text-xs sm:text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs border border-amber-400 cursor-pointer shadow-md flex items-center gap-2"
            >
              <span>Connect with Corporate Office</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            <button
              onClick={onOpenDealer}
              className="bg-white hover:bg-zinc-100 text-zinc-900 border border-zinc-300 font-display font-bold text-xs sm:text-sm uppercase tracking-wider px-6 py-3.5 rounded-xs shadow-xs cursor-pointer"
            >
              <span>Explore Dealer Network</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
